<template>
    <div >
        <!-- 个人信息 -->
        <el-row class="main-top">
            <div class="avatar">
                <el-tooltip content="点击上传头像" effect="light">
                    <el-upload
                        accept="image/*"
                        action=""
                        :show-file-list="false"
                        :http-request="uploadMainImg"
                        >
                        <el-avatar :size="120" :src="this.userInfo.imageUrl" >{{userInfo.nickName}}</el-avatar>
                    </el-upload>
                </el-tooltip>
            </div>
            <div class="info">
                <div>
                    <span class="meta-block">&nbsp;&nbsp;&nbsp;昵称：</span>
                    <span class="name">梦学谷</span>
                </div>
                <div>
                    <span class="meta-block">用户名：</span>
                    <span class="name">mengxuegu</span>
                </div>
            </div>
        </el-row>
        <el-row >
            <el-tabs value="public" @tab-click="handleClick" >
                <el-tab-pane label="公开文章" name="public">
                    <article-list/>
                </el-tab-pane>
                <el-tab-pane label="私密文章" name="nopublic">
                    <article-list/>
                </el-tab-pane>
                <el-tab-pane label="我的提问" name="question">
                    <question-list/>
                </el-tab-pane>
                <el-tab-pane label="修改个人资料" name="user">
                    <user-edit :loading="loading" :formData="userInfo" @submitForm="submitUserForm" />
                </el-tab-pane>
                <el-tab-pane label="修改密码" name="password">
                    <user-password :loading="loading" :formData="passwordData" @submitForm="submitPasswordForm" />
                </el-tab-pane>
            </el-tabs> 
        </el-row>
    </div>
</template>
<script>
import ArticleList from '@/components/article/List'
import QuestionList from '@/components/question/List'
import UserEdit from '@/components/user/Edit'
import UserPassword from '@/components/user/Password'

export default {
    components: { QuestionList, ArticleList, UserEdit, UserPassword }, 

    data() {
        return {
            loading: false,
            userInfo: {
                imageUrl: ''
            },
            passwordData: { // 修改密码表单
                userId: this.$store.state.userInfo.uid
            },
        }
    },

    methods: {
        handleClick(tab, event) {
            switch (tab.paneName) {
                case 'public':
                    break;
                case 'nopublic':
                    break;
                case 'question':
                    break;
                case 'user':
                    // 用户不用查询，在加载此页面时已经查询了
                    break;
            }
        },
        
        // 上传头像
        uploadMainImg(file) {
            
        },

        // 删除头像, 上传成功后删除原来的头像
        deleteImg() {
            
        },

        // 提交修改个人资料
        async submitUserForm() {
            this.loading = true
            alert(1)
        },

        // 修改密码
        async submitPasswordForm() {
        }
    },

    asyncData( {app} ) {
        // 1. 查询用户信息
        // 2. 查询公开文章列表
    },

}
</script>
<style scoped>
.main-top {
    padding: 30px 0;
}
.avatar{
    float:left;
}
.info {
    margin: 30px 0 0 140px;
}
.info .name {
    font-size: 18px;
    font-weight: 500;
    padding-top: 10px;
}
.info .meta-block {
    font-size: 14px;
    color: #969696;
}
</style>