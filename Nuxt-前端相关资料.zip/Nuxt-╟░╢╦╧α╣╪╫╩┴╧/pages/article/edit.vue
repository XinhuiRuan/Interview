<template>
    <!--弹窗 :close-on-click-modal="false" 点击遮罩层不关闭窗口 -->
    <div>
        <!-- status-icon 当表单校验不通过时, 输入框右侧有个 x 小图标 -->
        <el-form
        ref="formData"
        :model="formData"
        label-width="100px"
        label-position="right"
          >
          <el-form-item label="标题:" prop="title" >
              <el-input v-model="formData.title" placeholder="请输入标题"  
                        maxlength="50" show-word-limit/>
          </el-form-item>
          <el-form-item label="标签:" prop="labelIds" >
            <!--:show-all-levels="false" 仅显示最后一级， :filterable="true" 可搜索 
                props{ multiple: true 多选， emitPath: false 只返回子节点的value } -->
            <el-cascader 
                        :disabled="disabled"
                        style="display: block"
                        v-model="formData.labelIds"
                        :options="labelOptions"  
                        :show-all-levels="false"
                        :props="{ multiple: true, emitPath: false, children: 'labelList', value: 'id', label: 'name'}" 
                        :filterable="true"
                        clearable/>
          </el-form-item>
          <el-form-item label="主图:" prop="imageUrl" > 
          </el-form-item>
          <el-form-item label="是否公开:" prop="ispublic">
              <el-radio-group v-model="formData.ispublic">
                  <el-radio :label="0" >不公开 </el-radio>
                  <el-radio :label="1" >公开  </el-radio>
              </el-radio-group>
          </el-form-item>
          
          <el-form-item label="简介:" prop="summary">
              <el-input v-model="formData.summary"  type="textarea" 
                placeholder="请输入简介" :autosize="{ minRows: 3 }" maxlength="2000" show-word-limit/>
          </el-form-item>
          <el-form-item label="内容:" prop="content">
	          <!-- 主体内容 -->
          </el-form-item>
        </el-form>
      	<el-row type="flex" justify="center">
            <el-button type="primary" @click="submitForm('formData')">发布文章</el-button>
        </el-row>
    </div>
</template>

<script>

export default {
    data() {
        return {
            formData: {}, // 表单数据
            disabled: false, // 标签输入框默认可输入
            labelOptions: [ // 标签下拉框
                {
                id: 1,
                name: '前端',
                labelList: [
                    {
                    id: 1,
                    name: 'html'
                    }, {
                    id: 2,
                    name: 'js'
                    }, {
                    id: 3,
                    name: 'css'
                    }
                ]
                }, 
                {
                id: 2,
                name: 'Java',
                labelList: [
                    {
                    id: 4,
                    name: 'javase'
                    }, {
                    id: 5,
                    name: 'spring'
                    }, {
                    id: 6,
                    name: 'springboot'
                    }
                ]
                }
            ],
        }
    },

    methods: {
        // 提交表单
        submitForm() {
            
        }
    },
}
</script>
// import api from '@/api/article.js'
// import categoryApi from '@/api/category'
// import commonApi from '@/api/common'

// import { mavonEditor } from 'mavon-editor'
// import 'mavon-editor/dist/css/index.css'

// export default {
//   components: { mavonEditor },
//   // 接收父组件传递的属性
//   props: {
//     visible: { //弹出隐藏
//       type: Boolean,
//       default: false
//     },
//     title: { // 标题
//       type: String,
//       default: ''
//     },
//     formData: { // 表单数据
//         type: Object,
//         default: {}
//     },
//     oldImageUrl: String, // 旧主图 ，把修改前的图片url的缓存下来，以防改了图片但是表单没有保存，这样就不能把之前图片删除
//     remoteClose: Function // 用于关闭窗口
//   },

//   mounted() {
//     // 获取所有分类与标签
//     this.getLabelOptions()
//   },
//   methods: {
//     // mdContent: md 内容，htmlContent：转成后的html
//     getMdHtml(mdContent, htmlContent) {
//       // console.log('mdContent', mdContent)
//       // console.log('htmlContent', htmlContent)
//       // mdContent 在组件上 v-model=“formData.mdContent” 绑定了
//       this.formData.htmlContent = htmlContent
//     },
//     // 获取所有分类与标签
//     async getLabelOptions(){
//       // es6语法，不要少了 async， await
//       const { data }= await categoryApi.getCategoryAndLabel()
//       this.labelOptions = data
//     },
//     // 关闭弹窗
//     handleClose(done) {
//       // 表单清空
//       this.$refs['formData'].resetFields()
//       // 因为 visible 是父组件的属性，所以要让父组件去改变值 
//       this.remoteClose()
//     },

//     // 提交表单
//     submitForm (formName) {
//       // 校验通过
//       this.$refs[formName].validate((valid) => {
//         if (valid) {
//           // 校验通过，提交数据
//           this.submitData() 
//         } else {
//           // 验证不通过
//           return false;
//         }
//       })
//     },

//     // 3. 异步方法提交数据
//     async submitData() {
//       let response = null
//       // 有 id 值则修改，没有id则新增
//       if(this.formData.id) {
//         response = await api.update(this.formData)
//       }else {
//         response = await api.add(this.formData)
//       }
//       // 等上面返回数据response后再进行处理
//       if (response.code === 20000) {
//         // 提交成功, 关闭窗口, 刷新列表
//         this.$message({
//           message: '保存成功',
//           type: 'success'
//         })
//         // 关闭窗口
//         this.handleClose()
//       } else {
//         this.$message({
//           type: 'error',
//           message: "保存失败"
//         });
//       }
//     },

//     // 上传主图
//     uploadMainImg(file) {
//       // 封装表单对象
//       const data = new FormData()
//       data.append('file', file.file)
//       // 发送请求上传
//       commonApi.uploadImg(data).then(response => {
//         // 以防图片多次上传，上传成功后，把原来的图片删除
//         this.deleteImg()
//         this.formData.imageUrl = response.data
//       }).catch(() => {
//         this.$message({
//           showClose: true,
//           message: '上传失败',
//           type: 'error'
//         });
//       })
//     },

//     // 删除主图, 上传成功和关闭窗口调用删除上一次上传的图片
//     deleteImg() {
//       // 以防上传后，表单没有提交，这样就不能把进入到修改页面时最初的图片删除，如果删除了下次再点击修改，就找不到图片了，
//       if(this.formData.imageUrl && this.formData.imageUrl !== this.oldImageUrl) {
//         // const data = {'fileUrl': imageUrl}
//         // 删除
//         console.log('删除', this.formData.imageUrl, this.oldImageUrl)
//         commonApi.deleteImg(this.formData.imageUrl)
//       }
//     },

//     // 上传内容图片 (图片位置编号, File对象)
//     uploadContentImg(pos, file){
//       // 第一步.将图片上传到服务器
//       var fd = new FormData();
//       fd.append('file', file);
//       commonApi.uploadImg(fd).then(response => {
//         console.log(response)
//         // 第二步.将返回的url替换到文本原位置! [...](0) -> ![...](url)
//         this.$refs.md.$img2Url(pos, response.data)
//       })
//     },

//     // 删除内容图片
//     delContentImg(urlAndFileArr) {
//       const fileUrl = urlAndFileArr[0] // 文件URL
//       const file = urlAndFileArr[1] // File对象
//       console.log('删除图片', fileUrl, file)
//       commonApi.deleteImg(fileUrl)
//     }
//   },

//   data() {
//     const validateLabel = (rule, value, callback) => {
//       // value获取输入框的值
//       // 有 value 值才校验，不然提交的时候会报错
//       if(value && value.length>5){
//         this.disabled = true // 禁止点击
//         callback(new Error('最多可选5个标签'))
//       }else{
//         // 校验通过放行
//         callback()
//         this.disabled = false
//       }
//     } // 不要有逗号

//     const validateContent =  (rule, value, callback) => {
//       if( this.formData.mdContent &&  this.formData.htmlContent ){
//         // 有内容则放行
//         callback()
//       }else{
//         callback(new Error('请求输入文章内容'))
//       }
//     } // 不要有逗号

//     return {
//       rules: {
//         title: [{ required: true, message: '请输入标题', trigger: 'blur' }],
//         labelIds: [
//           { required: true, message: '请选择标签', trigger: 'blur' },
//           { validator: validateLabel, trigger: 'change' },
//         ],
//         ispublic: [{ required: true, message: '请选择是否公开', trigger: 'change' }],
//         summary: [{ required: true, message: '请输入简介', trigger: 'blur' }],
//         content: [{ validator: validateContent, trigger: 'change' }]
//       },
//       disabled: false, // 标签输入框默认可输入
//       labelOptions: [] // 标签
//     }
//   }
// }
// 
<style>
  .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 178px;
    height: 178px;
    line-height: 178px;
    text-align: center;
  }
  .avatar {
    width: 178px;
    height: 178px;
    display: block;
  }
</style>