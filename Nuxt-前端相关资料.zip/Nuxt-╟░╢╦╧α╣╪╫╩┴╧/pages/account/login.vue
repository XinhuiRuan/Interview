<template>
    <el-card >
        <el-row type="flex"  justify="center" >
            <h2>登 录</h2>
        </el-row>
        <el-row type="flex"  justify="center">
            <el-form :model="formData" :rules="rules" ref="dataForm" label-width="100px">
                <el-form-item label="用户名" prop="username">
                    <el-input v-model="formData.username" placeholder="请输入用户名" clearable style="width:320px" > </el-input>
                </el-form-item>
                <el-form-item label="密码" prop="password" >
                    <el-input v-model="formData.password" type="password" placeholder="请输入密码" style="width:320px" clearable ></el-input>
                    <el-link type="primary" href="/account/register" >去注册</el-link>
                    <div class="el-form-item__error">{{ message }}</div>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="submitForm('dataForm')" style="width:320px">登录</el-button>
                </el-form-item>
            </el-form>
        </el-row>
    </el-card>
</template>
<script>
export default {
    head() {
        return {
            title: '登录-梦学谷在线教育'
        }
    },
    data() {
        return {
            formData: {},
            message: '', // 登录失败提示信息
            rules: { // 定义表单校验规则

            }
        }
    },

    methods: {
        
        // 提交表单
        submitForm(formName) {

        },

    }

}
</script>

