<template>
    <div>
        <!-- 面包屑 https://element.eleme.cn/#/zh-CN/component/breadcrumb -->
        <el-breadcrumb separator-class="el-icon-arrow-right" >
            <el-breadcrumb-item :to="{ path: '/label' }">标签</el-breadcrumb-item>
            <el-breadcrumb-item :to="{ path: $route.path }">{{$route.params.id}}</el-breadcrumb-item>
            <el-breadcrumb-item>标签动态</el-breadcrumb-item>
        </el-breadcrumb>
        
        <el-table class="label-list"
            :show-header="false"
            :data="listData"
            style="width: 100%"
            height="250">
            <el-table-column width="70">
                <template slot-scope="scope">
                    <el-tag class="count">
                        {{ scope.row.viewCount }} <br>浏览
                    </el-tag>
                </template>
            </el-table-column>
            <el-table-column>
                <template slot-scope="scope">
                    <h2 class="title">
                        <nuxt-link to="/article/11" target="_blank"> 
                            {{ scope.row.title }}
                        </nuxt-link>
                    </h2>
                    <div class="info">
                        <i class="el-icon-user"></i>{{ scope.row.nickName }} &nbsp;
                        <i class="el-icon-date"></i> {{ scope.row.createDate }}
                    </div>
                    
                </template>
            </el-table-column>
        </el-table>
    </div>
</template>
<script>
export default {
    // validate ({ params }) {
    //     console.log(params.id)
    // },
    data() {
        return {
            listData: [
                {id: '11', nickName: 'meng', title: 'aaa', viewCount: 10, createDate: '2019-12-12'},
                {id: '22', nickName: 'xue', title: 'aaa', viewCount: 10, createDate: '2019-12-12'},
                {id: '33', nickName: 'gu', title: 'aaa', viewCount: 10, createDate: '2019-12-12'},
            ]
        }
    }
}
</script>
<style scoped>
.label-list {
    margin-top: 30px
}
.label-list .count {
    text-align: center;
    height: 100%; 
    line-height: 20px;
}
.label-list .info {
    color: #999;
    font-size: 13px;
}
.label-list .title {
    display: inline-block;
    margin: 0 5px 0 0;
    font-size: 16px;
    height: 22px;
    line-height: 22px;
}
a:hover{
  text-decoration-line: underline;
}
</style>
