<template>
    <!-- 文章列表 -->
    <div id="list-container">
        <ul class="note-list">
            <!-- 无主图 -->
            <li >
                <div class="content">
                <!-- <nuxt-link> 与 <router-link> 用法一致 -->
                <nuxt-link to="/article/111" target="_blank">
                    <p class="title">canvas 必备的动画效果大全</p>  
                    <p class="abstract">
                    它本身就像一个画布，JavaScript 通过操作它的 API，在上面生成图像。它的底层是一个个像素，基本上一个可以用 JavaScript 操作的位图（bitmap）。
                    是脚本调用各种方法生成图像，SVG 则是一个 XML 文件，通过各种子元素生成图像。
                    </p>
                </nuxt-link>
                <div class="meta">
                    <nuxt-link to="/user/111" target="_blank" class="nickname jsd-meta"> 
                    <i class="el-icon-user-solid"></i> 梦学谷
                    </nuxt-link>
                    <span><i class="el-icon-thumb"></i> 42</span>
                    <span><i class="el-icon-view"></i> 266</span>
                </div>
                </div>
            </li>

            <!-- 有主图 -->
            <li class="have-img">
                <div class="content">
                <nuxt-link to="/article/333" target="_blank">
                    <p class="title">走进互联网应用—从单体应用到微服务架构</p> 
                    <p class="abstract">
                    介绍目前互联网应用开发的主流框架，包括：Spring、SpringMVC、MyBatis、SpringBoot以及SpringCloud，讲解技术更新迭代的过程，以及大型项目的架构设计思想
                    </p>
                </nuxt-link>
                <div class="meta">
                    <nuxt-link to="/user/111" target="_blank" class="nickname jsd-meta"> 
                    <i class="el-icon-user-solid"></i> 梦学谷
                    </nuxt-link>
                    <span><i class="el-icon-thumb"></i> 42</span>
                    <span><i class="el-icon-view"></i> 266</span>
                </div>
                </div>
                <!-- 图片 -->
                <nuxt-link to="/article/333" class="wrap-img" target="_blank">
                  <img src="https://img.alicdn.com/bao/uploaded/i2/3603079088/O1CN01rGCkfb2H0M1O7Lj45_!!0-item_pic.jpg" >
                </nuxt-link>
            </li>
        </ul>
    </div>
</template>
<style >
/* 上面不要用 scoped，因为要被引入 index.vue 中 */
@import '@/assets/css/blog/list.css';
</style>
