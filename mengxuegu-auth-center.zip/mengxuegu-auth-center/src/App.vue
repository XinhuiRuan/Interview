<template>
  <div id="app">
    <img alt="Vue logo" src="./assets/image/logo.png">
    <h1>Hello，梦学谷——陪你学习，伴你梦想</h1>
  </div>
</template>

<script>

export default {
  name: 'App',
}
</script>

<style>
#app {
  text-align: center;
  color: #2c3e50;
}
</style>
