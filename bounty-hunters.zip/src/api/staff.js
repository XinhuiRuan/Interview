import request from "@/utils/request"

export default{
    // 分页查询
    // page当前页码，size 每页显示条数, searchMap 条件
    // 后台要通过 page 和 size 统计本次请求响应的数据
    search(page, size, searchMap){
        return request({
            url: `/staff/list/search/${page}/${size}`,
            method: "post",
            data: searchMap
        })
    },

    // 新增员工
    add(pojo){
        return request({
            url: '/staff',
            method: "post",
            data: pojo
        })
    },

    // 根据员工ID查询数据
    getById(id){
        return request({
            url: `/staff/${id}`,
            method: "get"
        })
    },

    // 根据员工ID更新数据
    updateById(pojo){
        return request({
            url: `/staff/${pojo.id}`,
            method: "put",
            data: pojo
        })
    },

    // 根据员工ID删除数据
    deleteById(id){
        return request({
            url: `/staff/${id}`,
            method: "delete"
        })
    }
}