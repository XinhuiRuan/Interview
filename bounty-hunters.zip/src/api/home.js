import request from "@/utils/request"

export default{
    // 根据主页得到相关的图片
    getHomeImgs(page){
        return request({
            url: `/imgs/${page}`,
            method: "get"
        })
    },
}