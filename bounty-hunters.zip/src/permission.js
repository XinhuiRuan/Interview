/*
权限校验：
通过router路由前置钩子函数 beforeEach() ，
在跳转路由前进行拦截判断是否已经登录，
如果已登录，则进行路由跳转，如果没有则回到登录页
*/

import router from './router'
import { getUserInfo } from './api/login'
import store from './store'
/*
前置路由钩子函数
to ：即将要进入的目标路由对象
from ：当前导航正要离开的路由对象
next : 调用该方法，进入目标路由
*/
router.beforeEach((to, from, next) => {
    // 第一步：获取token
    // const token = localStorage.getItem('mxg-msm-token'); 
    const token = store.state.user.token;
    // 第二步：判断有无 token
    // 如果无 token
    if (!token) {
        // 第三步：判断是否访问登录页面
        // 如果不是，强制路由到登录页面
        if (to.path !== '/login') {
            next({ path: '/login' });
        } else {
            // 如果是，则正常进入目标页面  
            next();
        }
    } else {
        // 如果有 token
        // 第三步：判断是否访问登录页面
        // 如果是，则进入正常进入目标页面
        if (to.path === '/login') {
            next();
        } else {
            // 如果不是
            // 第四步：检查是否有用户信息
            //const userInfo = localStorage.getItem('mxg-msm-user');
            const userInfo = store.state.user.user;
            // 如果有，则进入正常进入目标页面
            if (userInfo) {
                next();
            } else {
                // 如果没有
                store.dispatch('GetUserInfo').then(response => {
                    if (response.flag) {
                        // 进入正常进入目标页面
                        next();
                    } else {
                        // 未获取到,重新登录
                        next({ path: '/login' })
                    }
                }).catch(error => {

                })
            }
        }
    }


})
