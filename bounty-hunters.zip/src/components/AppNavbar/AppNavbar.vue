<template>
  <div class="navbar">

    <!-- :router 开启路由功能,则 index指定路由地址
    default-active 默认选中哪个菜单,选中为黄色,
    注意 v-bind:default-active 才可以指定表达式-->
    <!-- <el-menu
      :router="true"
      :default-active="$route.path"
      class="el-menu-vertical-demo"
      background-color="#545c64"
      text-color="#fff"
      active-text-color="#ffd04b"
    >
      <el-menu-item index="/home">
        <i class="el-icon-s-home"></i>
        <span slot="title">首页</span>
      </el-menu-item>
      <el-menu-item index="/member/">
        <i class="el-icon-user-solid"></i>
        <span slot="title">会员管理</span>
      </el-menu-item>
      <el-menu-item index="/supplier/">
        <i class="el-icon-s-cooperation"></i>
        <span slot="title">供应商管理</span>
      </el-menu-item>
      <el-menu-item index="/goods/">
        <i class="el-icon-s-goods"></i>
        <span slot="title">商品管理</span>
      </el-menu-item>
      <el-menu-item index="/staff/">
        <i class="el-icon-user"></i>
        <span slot="title">员工管理</span>
      </el-menu-item>
    </el-menu> -->

    <van-tabbar v-model="active" class="active_tab">
    <!-- 路由模式下会匹配页面路径和标签的to属性，并自动选中对应的标签 -->
    <van-tabbar-item
      v-for="(item,index) in tabbars"
      :key="index"
      :to="item.name"
      @click="tab(index,item.name)"
    >
      <span :class="currIndex == index ? active:''">{{item.title}}</span>
      <template slot="icon" slot-scope="props">
        <img :src="props.active ? item.active : item.normal">
      </template>
    </van-tabbar-item>
  </van-tabbar>

  </div>
</template>

<script>
export default {
  data() {
    return {
      currIndex: 0,
      active: 0,
      tabbars: [
        {
          name: "/home",
          title: "首页",
          normal: require("@/assets/NavbarIcons/home.png"),
          active: require("@/assets/NavbarIcons/home_ac.png")
        },
        {
          name: "/answer",
          title: "答疑解惑",
          normal: require("@/assets/NavbarIcons/answer.png"),
          active: require("@/assets/NavbarIcons/answer_ac.png")
        },
        {
          name: "/member",
          title: "会员",
          normal: require("@/assets/NavbarIcons/member.png"),
          active: require("@/assets/NavbarIcons/member_ac.png")
        }
      ]
    };
  },

  components: {},

  methods: {
    tab(index, val) {
      // this.currIndex = index;
      // this.$router.push(val);
    }
  }
};
</script>

<style scoped>
.el-menu{
  border-right: none;
}

.active_tab img {
  /* width: 26px; */
  height: 26px;
}

.van-tabbar-item--active {
  color: #1E90FF;
}
</style>