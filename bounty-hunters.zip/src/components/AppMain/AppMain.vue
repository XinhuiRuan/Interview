<template>
  <div class="main">
    <!-- 使用 v-show 判断路由为 /home 时不显示横向指示导航 -->
    <!-- <app-link v-show="$route.path !== '/home'"></app-link> -->
    <app-link></app-link>

    <!-- 子路由渲染出口 -->
    <router-view></router-view>
  </div>
</template>

<script>
import AppLink from './AppLink.vue'

export default {
  data() {
    return {};
  },

  components: {AppLink},

  methods: {}
};
</script>

<style scoped>

</style>