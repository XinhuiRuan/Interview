<template>
  <div class="header">
    <!-- 头部左侧Logo和标题 -->
    <a href="#/">
      <img class="logo" src="@/assets/logo.png" alt />
      <span class="company">梦学谷管理系统</span>
    </a>

    <!-- 头部右侧下拉菜单 -->
    <el-dropdown @command="handleCommand">
      <span class="el-dropdown-link">
        <!-- 下拉菜单 -->
        {{user.name}}
        <i class="el-icon-arrow-down el-icon--right"></i>
      </span>
      <el-dropdown-menu slot="dropdown">
        <el-dropdown-item icon="el-icon-edit" command="editPwd">修改密码</el-dropdown-item>
        <el-dropdown-item icon="el-icon-close" command="logout">退出系统</el-dropdown-item>
      </el-dropdown-menu>
    </el-dropdown>

    <!-- 新增修改密码的弹出框 -->
    <el-dialog title="修改密码" :visible.sync="dialogFormVisible" width="400px">
      <el-form
        :model="ruleForm"
        status-icon
        :rules="rules"
        ref="ruleForm"
        label-width="100px"
        style="width: 300px;"
      >
        <el-form-item label="原密码" prop="oldPwd">
          <el-input type="password" v-model="ruleForm.oldPwd" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="新密码" prop="newPwd">
          <el-input type="password" v-model="ruleForm.newPwd" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="确认密码" prop="checkPwd">
          <el-input type="password" v-model="ruleForm.checkPwd" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="submitForm('ruleForm')">提交</el-button>
          <el-button @click="$refs['ruleForm'].resetFields();">重置</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>

<script>
import { logout } from "@/api/login";
import Password from "@/api/password";

export default {
  data() {
    // 校验原密码
    const validateOldPwd = (rule, value, callback) => {
      if (!value) {
        return callback(new Error("原密码不能为空"));
      }
      Password.checkPwd(this.user.id, value).then(response => {
        const resp = response.data;
        if (resp.flag) {
          return callback();
        } else {
          return callback(new Error(resp.message));
        }
      });
    };

    // 校验确认新密码
    const validateCheckPwd = (rule, value, callback) => {
      if (!value) {
        return callback(new Error("确认密码不能为空"));
      }
      if (value !== this.ruleForm.newPwd) {
        return callback(new Error("两次输入密码不一致"));
      } else {
        return callback();
      }
    };

    return {
      dialogFormVisible: false,
      ruleForm: {
        oldPwd: "",
        newPwd: "",
        checkPwd: ""
      },
      // user 获取用户信息
      // user: JSON.parse(localStorage.getItem('mxg-msm-user')), // 将string转为object
      user: this.$store.state.user.user,
      rules: {
        oldPwd: [
          // {required: true, message: "原密码不能为空", trigger: "blur"}
          { required: true, validator: validateOldPwd, trigger: "blur" }
        ],
        newPwd: [
          { required: true, message: "新密码不能为空", trigger: "blur" }
        ],
        checkPwd: [
          { required: true, validator: validateCheckPwd, trigger: "change" }
        ]
      }
    };
  },

  components: {},

  methods: {
    handleCommand(command) {
      //this.$message('click on item ' + command);
      switch (command) {
        case "editPwd":
          // 修改密码
          this.handlePwd();
          break;
        case "logout":
          // 退出系统
          this.handleLogout();
          break;
      }
    },

    // 退出系统
    handleLogout() {
      this.$store.dispatch("Logout").then(response => {
          if (response.flag) {
            // 退出成功，回到登陆页面
            this.$router.push("/login");
          } else {
            this.$message({
              message: response.message,
              type: "warning",
              duration: 500 // 弹出停留时间
            });
          }
        }).catch(error => {

        });
    },

    // 修改密码
    handlePwd() {
      this.dialogFormVisible = true;
      this.$nextTick(() => {
        this.$refs["ruleForm"].resetFields();
      });
    },

    // 修改密码弹出框 —— 提交
    submitForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          // 验证通过，提交添加
          Password.updatePwd(this.user.id, this.ruleForm.newPwd).then(
            response => {
              const resp = response.data;
              this.$message({
                message: resp.message,
                type: resp.flag ? "success" : "warning"
              });
              if (resp.flag) {
                // 修改成功, 清除本地数据, 重新登录
                this.handleLogout();
                // 关闭窗口
                this.dialogFormVisible = false;
              }
            }
          );
        } else {
          // 验证不通过
          return false;
        }
      });
    }
  }
};
</script>

<style scoped>
.logo {
  vertical-align: middle;
  width: 25px;
  /* 上 右 下 左 */
  padding: 0 10px 0 40px;
}

.company {
  position: absolute;
  color: white;
}

/* 下拉菜单 */
.el-dropdown {
  float: right;
  margin-right: 40px;
}
.el-dropdown-link {
  cursor: pointer;
  color: #fff;
}
</style>