import Vue from "vue";
import Router from "vue-router";
// 默认导入目录下的 index.vue 文件，等价于 ./views/login/index.vue，只适用于取名字为 index.vue
import Login from "./views/login"
import Layout from "./components/Layout.vue"
import Main from "./components/AppMain/AppMain.vue"
import Home from "./views/home/home.vue"
import Join from "./views/home/join.vue"
import Recommend from "./views/home/recommend.vue"
import Recruitment from "./views/home/recruitment.vue"
import Resumes from "./views/home/resumes.vue"
import Answer from "./views/answer/answer.vue"
import Member from "./views/member/member.vue"
import Supplier from "./views/supplier/supplier.vue"
import Goods from "./views/goods/goods.vue"
import Staff from "./views/staff/staff.vue"

Vue.use(Router);

export default new Router({
  mode:"history",//去除哈希值的#号s
  routes: [
    // {
    //   // 登录页
    //   path: "/login",
    //   name: 'login', //路由名称
    //   component: Login
    // },
    {
      // 基础布局
      path: "/",
      name: 'layout', //路由名称
      component: Layout,
      redirect: '/home', // 重定向到子路由
      children: [
        {
          path: '/home',
          component: Home,
          meta: {title: '赏金猎人'}
        },
        // 第一种：写之后几个组件路由的方法，但会显得冗余，推荐第二种
        // {
        //   path: '/member/',
        //   component: Member,
        //   meta: {title: '会员管理'}
        // }
      ]
    },
    {
      // 我要加入
      path: '/home/join',
      component: Main,
      children: [
        {
          path: '/',
          component: Join,
          meta: {title: '资料填写'}
        }
      ]
    },
    {
      // 我要推荐
      path: '/home/recommend',
      component: Recommend
    },
    {
      // 招募推广
      path: '/home/recruitment',
      component: Recruitment
    },
    {
      // 收集简历查询
      path: '/home/resumes',
      component: Resumes
    },
    // 第二种：写之后几个组件的路由的方法
    {
      path: '/member',
      component: Layout,
      children: [
        {
          path: '/',
          component: Member,
          meta: {title: '会员中心'}
        }
      ]
    },
    {
      path: '/answer',
      component: Layout,
      children: [
        {
          path: '/',
          component: Answer,
          meta: {title: '答疑解惑'}
        }
      ]
    },
    // {
    //   path: '/supplier',
    //   component: Layout,
    //   children: [
    //     {
    //       path: '/',
    //       component: Supplier,
    //       meta: {title: '供应商管理'}
    //     }
    //   ]
    // },
    // {
    //   path: '/goods',
    //   component: Layout,
    //   children: [
    //     {
    //       path: '/',
    //       component: Goods,
    //       meta: {title: '商品管理'}
    //     }
    //   ]
    // },
    // {
    //   path: '/staff',
    //   component: Layout,
    //   children: [
    //     {
    //       path: '/',
    //       component: Staff,
    //       meta: {title: '员工管理'}
    //     }
    //   ]
    // },
  ]
});
