<template>
  <div>
    <!-- 条件查询, inline 属性设置表单变为行内的表单域 -->
    <el-form ref="searchForm" :inline="true" :model="searchMap" style="margin-top: 20px;">
      <!-- 在 el-form-item 标签属性 prop 上, 指定了字段名, 重置才会生效 -->
      <el-form-item prop="name">
        <el-input v-model="searchMap.name" placeholder="商品名称" style="width: 200px;"></el-input>
      </el-form-item>
      <el-form-item prop="code">
        <el-input v-model="searchMap.code" placeholder="商品编码" style="width: 200px;"></el-input>
      </el-form-item>
      <el-form-item prop="supplierName">
        <!-- el-input 是组件，要在组件元素监听原生事件，需要使用 v-on:原生事件名.native="处理函数" -->
        <el-input
          readonly
          @click.native="dialogSupplierVisible = true"
          v-model="searchMap.supplierName"
          placeholder="供应商"
          style="width: 200px;"
        ></el-input>
      </el-form-item>

      <el-form-item>
        <el-button type="primary" @click="fetchData">查询</el-button>
        <el-button @click="handleAddDialog('pojoForm')">新增</el-button>
        <el-button @click="$refs['searchForm'].resetFields()">重置</el-button>
      </el-form-item>
    </el-form>

    <!-- 列表-->
    <!-- :data 绑定渲染的数据；border: 边框; -->
    <el-table :data="list" height="480" border style="width: 100%;">
      <!--type="index" 获取索引值，从1开始； label 显示的标题; prop 数据字段名； width 列的宽度-->
      <el-table-column type="index" label="序号" width="60"></el-table-column>
      <el-table-column prop="name" label="商品名称"></el-table-column>
      <el-table-column prop="code" label="商品编码" width="120"></el-table-column>
      <el-table-column prop="spec" label="商品规格"></el-table-column>
      <el-table-column prop="retailPrice" label="零售价"></el-table-column>
      <el-table-column prop="storageNum" label="进货价"></el-table-column>
      <el-table-column prop="supplierName" label="供应商"></el-table-column>
      <el-table-column label="操作" width="150">
        <!-- 通过 Scoped slot 可以获取到 row, column, $index 和 store（table 内部的状态管理）的数据 -->
        <template slot-scope="scope">
          <el-button size="mini" @click="handleEdit(scope.row.id)">编辑</el-button>
          <el-button size="mini" type="danger" @click="handleDelete(scope.row.id)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页功能 -->
    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="currentPage"
      :page-sizes="[10, 20, 50]"
      :page-size="pageSize"
      layout="total, sizes, prev, pager, next, jumper"
      :total="total"
    ></el-pagination>

    <!-- 新增对话框 -->
    <el-dialog v-if="!isDialog" title="商品编辑" :visible.sync="dialogFormVisible" width="500px">
      <el-form
        :model="pojo"
        :rules="rules"
        ref="pojoForm"
        label-width="100px"
        label-position="right"
        style="width:400px;"
      >
        <el-form-item label="商品名称" prop="name">
          <el-input v-model="pojo.name"></el-input>
        </el-form-item>
        <el-form-item label="商品编码" prop="code">
          <el-input v-model="pojo.code"></el-input>
        </el-form-item>
        <el-form-item label="商品规格" prop="spec">
          <el-input v-model="pojo.spec"></el-input>
        </el-form-item>
        <el-form-item label="零售价" prop="retailPrice">
          <el-input v-model="pojo.retailPrice"></el-input>
        </el-form-item>
        <el-form-item label="进货价" prop="purchasePrice">
          <el-input v-model="pojo.purchasePrice"></el-input>
        </el-form-item>
        <el-form-item label="库存数量" prop="storageNum">
          <el-input v-model="pojo.storageNum"></el-input>
        </el-form-item>
        <el-form-item label="供应商" prop="supplierName">
          <!-- el-input 是组件，要在组件元素监听原生事件，需要使用 v-on:原生事件名.native="处理函数" -->
          <el-input
            readonly
            @click.native="dialogSupplierVisible = true"
            v-model="pojo.supplierName"
            placeholder="选择供应商"
            style="width: 200px;"
          ></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="confirmDate('pojoForm')">确 定</el-button>
      </div>
    </el-dialog>

    <el-dialog title="选择供应商" :visible.sync="dialogSupplierVisible" width="500px">
      <supplier @option-supplier="optionSupplier" :isDialog="true"></supplier>
    </el-dialog>
  </div>
</template>

<script>
import goodsApi from "@/api/goods";
import Supplier from "@/views/supplier/supplier.vue";

export default {
  components: { Supplier },

  data() {
    return {
      list: [],
      total: 0, // 总记录数
      currentPage: 1, // 当前页, 默认第1页
      pageSize: 10, // 每页显示条数， 10条
      searchMap: {
        name: "",
        code: "",
        supplierName: "",
        supplierId: ""
      }, // 条件查询绑定条件值
      dialogSupplierVisible: false, // 选择供应商弹出框
      isDialog: false,
      dialogFormVisible: false, // 新增对话框
      rules: {
        name: [
          { required: true, message: "商品名称不能为空", trigger: "blur" }
        ],
        code: [
          { required: true, message: "商品编码不能为空", trigger: "blur" }
        ],
        retailPrice: [
          { required: true, message: "零售价不能为空", trigger: "blur" }
        ]
      },
      pojo: {
        id: null,
        name: "",
        code: "",
        spec: "",
        retailPrice: 0.0,
        purchasePrice: 0.0,
        storageNum: 0,
        supplierName: "",
        supplierId: null
      }
    };
  },

  // 钩子函数获取数据
  created() {
    this.fetchData();
  },

  methods: {
    fetchData() {
      goodsApi
        .search(this.currentPage, this.pageSize, this.searchMap)
        .then(response => {
          const resp = response.data.data;
          this.total = resp.total;
          this.list = resp.rows;
          //console.log(this.list);
        });
    },

    // 当每页显示条数改变之后被触发，val是最新的每页显示条数
    handleSizeChange(val) {
      this.pageSize = val;
      this.fetchData();
    },
    // 当前页码改变之后被触发，val是最新的页码
    handleCurrentChange(val) {
      this.currentPage = val;
      this.fetchData();
    },

    // 打开新增窗口
    handleAddDialog(formName) {
      this.dialogFormVisible = true;
      // 弹出窗口打开之后，需要加载Dom, 就需要花费一点时间，应该等待它加载完dom之后，再进行调用resetFields方法，重置表单和清除样式
      // this.$nextTick()是一个异步事件，当渲染结束之后 ，其回调函数才会被执行
      this.$nextTick(() => {
        // 为了使重置清除数据有效，需要有必须的两步设置：
        // 1. 表单formName内每个<el-form-item>必须设置prop属性等于该字段名
        // 2. vue实例的data中必须对每个字段名进行初始化，比如pojo对象
        this.$refs[formName].resetFields();
      });
    },

    // 提交新增数据 或者 更新数据 (通过pojo.id是否有值进行判断)
    confirmDate(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          //验证通过，提交添加 或者 更新
          let apiObj = this.pojo.id ? goodsApi.updateById(this.pojo) : goodsApi.add(this.pojo);
          apiObj.then(response => {
            const resp = response.data;
            if (resp.flag) {
              // 操作成功, 刷新列表数据
              this.fetchData();
              this.dialogFormVisible = false;
            }else {
              // 失败，弹出提示
              this.$message({
                message: resp.message,
                type: "warning"
              });
            }
          })
        } else {
          // 验证不通过
          return false;
        }
      });
    },

    // 编辑操作
    handleEdit(id) {
      // 清空原数据
      this.handleAddDialog('pojoForm');
      // 通过ID查询数据
      goodsApi.getById(id).then( response => {
        const resp = response.data;
        if(resp.flag){
          this.pojo = resp.data;
        }
      })
    },

    // 删除操作
    handleDelete(id) {
      this.$confirm("确认删除这条记录吗？", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          // 确认
          goodsApi.deleteById(id).then(response => {
            const resp = response.data;
            // 提示消息
            this.$message({
              type: resp.flag ? "success" : "error",
              message: resp.message
            });

            if(resp.flag){
              // 删除成功，查询数据
              this.fetchData();
            }
          });
        })
        .catch(() => {
          // 取消删除，不理会
        });
    },

    optionSupplier(currentRow) {
      // currentRow 子组件传递的数据
      //console.log('patenr',currentRow)
      if (this.dialogFormVisible) {
        //
        this.pojo.supplierName = currentRow.name; // 供应商名称
        this.pojo.supplierId = currentRow.id; // 供应商ID
      } else {
        this.searchMap.supplierName = currentRow.name; // 供应商名称
        this.searchMap.supplierId = currentRow.id; // 供应商ID
      }
      this.dialogSupplierVisible = false; //关闭窗口
    }
  }
};
</script>

<style scoped>
</style>