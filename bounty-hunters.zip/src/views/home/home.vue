<template>
  <div>
    <!-- <h1>欢迎访问赏金猎人</h1> -->
    <!-- 轮播图片 -->
    <div style="background-color:red;">
      <van-swipe :autoplay="3000" :height="180" >
        <van-swipe-item v-for="(image, index) in swipeImages" :key="index">
          <!-- <img v-lazy="image" /> -->
          <van-image height="180" radius="15" :src=image />
        </van-swipe-item>
      </van-swipe>
    </div>

    <!-- 四个按钮 -->
    <div class='btnGroup'>
      <van-button type="info" to="/home/join">我要加入</van-button>
      <van-button color="#FF9900" to="/home/recommend">我要推荐</van-button>
      <van-button color="#00CCFF" to="/home/recruitment">招募推广</van-button>
      <van-button color="#00CCFF" to="/home/resumes">收集简历查询</van-button>
    </div>

    <div align="center" style="background-color:red;">
      <van-image height="180" radius="15" :src=image />
    </div>

    <div align="center">
      <h3>招聘信息一键发布</h3>
    </div>
    
  </div>
</template>

<script>
export default {
  data() {
    return {
      swipeImages: [
        require('@/assets/TmpImages/swipeImg1.jpg'),
       // require('@/assets/TmpImages/swipeImg2.jpg'),
        //'https://img.yzcdn.cn/vant/apple-1.jpg',
        //'https://img.yzcdn.cn/vant/apple-2.jpg'
      ],
      image: require('@/assets/TmpImages/swipeImg1.jpg')
    }
  },

  components: {},

  methods: {
    
  },

  // mounted() {
  //     debugger
  //     this.$refs.recommend.style.bottom = bottom;
  //     this.$refs.scroll.refresh()
  //   },
}
</script>

<style scoped>
/* div{
  text-align: center;
} */
/* .van-swipe__track {
  height: 200px;
} */

.btnGroup{
  padding-bottom:5%;
}

.van-button{
  width:35%;
  margin-left:10%;
  margin-top:5%;
}

h3{
  margin: 2vh 0;
}

h3:after
{
  content : '';
  height : 50px;
  display :block;
}
</style>