<template>
  <div>
    <!-- <h1>欢迎访问赏金猎人</h1> -->
    <!-- 轮播图片 -->
    <div>
      <van-swipe :autoplay="3000" :height="180" >
        <van-swipe-item v-for="(image, index) in swipeImgs" :key="index">
          <!-- <img v-lazy="image" /> -->
          <a :href=image.to>
            <van-image height="180" radius="10" :src=image.url :href=image.to />
          </a>
        </van-swipe-item>
      </van-swipe>
    </div>

    <!-- 四个按钮 -->
    <div class='btnGroup'>
      <van-button type="info" to="/home/join">我要加入</van-button>
      <van-button color="#FF9900" to="/home/recommend">我要推荐</van-button>
      <van-button color="#00CCFF" to="/home/recruitment">招募推广</van-button>
      <van-button color="#00CCFF" to="/home/resumes">收集简历查询</van-button>
    </div>

    <div align="center">
      <a :href=promotionImg.to>
        <van-image height="180" radius="10" :src=promotionImg.url :href=promotionImg.to />
      </a>
    </div>

    <div align="center">
      <h3>招聘信息一键发布</h3>
    </div>
    
  </div>
</template>

<script>
import homeApi from "@/api/home";

export default {
  data() {
    return {
      swipeImgs: [
        {
          url: require('@/assets/TmpImages/swipeImg2.jpg'),
          to: ""
        }
        // require('@/assets/TmpImages/swipeImg1.jpg'),
        //'https://img.yzcdn.cn/vant/apple-1.jpg',
        //'https://img.yzcdn.cn/vant/apple-2.jpg'
      ],
      promotionImg: {
        url: require('@/assets/TmpImages/swipeImg1.jpg'),
        to: ""
      }
      // swipeImgs: [],
      // promotionImg: {}
    }
  },

  components: {},

  // 钩子函数获取图片数据
  created() {
    //this.fetchImgs();
  },

  methods: {
    // 获取轮播和宣传栏的图片信息
    fetchImgs(){
      homeApi.getHomeImgs("home").then(response => {
        const resp = response.data;
        if(resp.flag){ // 查询成功
          const imgs = resp.data;         
          for(const item of imgs){
            let imgObj = {
                url: item.url,
                to: item.to
            };

            if(item.type == "promotion"){
              this.promotionImg = imgObj;
            }else if(item.type == "swipe"){
              this.swipeImgs[item.seq] = imgObj;
            }
          }
        }
      })
    }
  },

}
</script>

<style scoped>
/* div{
  text-align: center;
} */
/* .van-swipe__track {
  height: 200px;
} */

.btnGroup{
  padding-bottom:5%;
}

.van-button{
  width:35%;
  margin-left:10%;
  margin-top:5%;
}

h3{
  margin: 2vh 0;
}

h3:after
{
  content : '';
  height : 50px;
  display :block;
}
</style>