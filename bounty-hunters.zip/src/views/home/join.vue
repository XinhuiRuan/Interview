<template>
  <div>
    <div align="center">
      <van-image height="180" radius="10" :src="joinImg" />
    </div>

<ValidationObserver ref="form">
  <ValidationProvider name="email" rules="required|email" v-slot="{ errors }">
        <input type="text" v-model="email" placeholder="type some email">
        <span>{{ errors[0] }}</span>
      </ValidationProvider>
</ValidationObserver>

    <div class="submitForm">

      <!-- 输入手机号码，调起手机号键盘 -->
      <van-cell-group>
        <van-field
          v-model="joinForm.phone"
          required
          type="tel"
          label="手机号码："
          placeholder="请输入手机号"
          :error-message="phoneTip"
          @blur="handlePhoneLength"
        />
      </van-cell-group>
      <!-- 输入短信验证码 -->
      <van-field v-model="joinForm.sms" required center clearable label="短信验证码：" placeholder="请输入短信验证码">
        <van-button slot="button" size="small" type="primary">发送验证码</van-button>
      </van-field>
      <!-- 输入人员姓名 -->
      <van-field v-model="joinForm.name" required label="人员姓名：" placeholder="请输入姓名" />
      <!-- 输入身份证号码 -->
      <van-field v-model="joinForm.idCard" required label="身份证号：" placeholder="请输入身份证号（X需要大写）" />

      <!-- 允许输入整数，调起数字键盘 -->
      <!-- <van-field v-model="digit" type="digit" label="整数" /> -->
      <!-- 允许输入数字，调起全键盘 -->
      <!-- <van-field v-model="number" type="number" label="数字" /> -->
      <!-- 输入密码 -->
      <!-- <van-field v-model="password" type="password" label="密码" /> -->

      <!-- 所在地区 -->
      <van-field
        readonly
        clickable
        required
        label="所在地区："
        :value="joinForm.selectedCity"
        placeholder="-请选择-"
        @click="showPicker1 = true"
      />
      <van-popup v-model="showPicker1" position="bottom">
        <van-picker
          show-toolbar
          :columns="citys"
          @cancel="showPicker1 = false"
          @confirm="onConfirmCity"
          @change="onChangeCity"
        />
      </van-popup>

      <!-- 职业 -->
      <van-field
        readonly
        clickable
        label="职业："
        :value="joinForm.selectedJob"
        placeholder="-请选择-"
        @click="showPicker2 = true"
      />
      <van-popup v-model="showPicker2" position="bottom">
        <van-picker
          show-toolbar
          :columns="jobs"
          @cancel="showPicker2 = false"
          @confirm="onConfirmJob"
        />
      </van-popup>

      <!-- 同意框 -->
      <van-checkbox v-model="checked" shape="square">
        <span @click="showDialog">我已阅读并知晓加盟须知</span>
      </van-checkbox>
    </div>

    <div class="btnGroup">
      <van-button type="info" @click="submitForm">提交</van-button>
      <van-button color="#00CCFF" to="/home">不了，我再逛逛</van-button>
    </div>
  </div>
</template>

<script>
import joinApi from "@/api/join";
import Citys from "@/assets/citys";
import { ValidationProvider, ValidationObserver } from "vee-validate";

Object.defineProperty(String.prototype, 'trimMultiSpace', {
        enumerable: false,
        value: function () {
                return this.replace(/ *[' '] */gm, '') //将字符串的空格都去掉
        }
})

export default {
  data() {
    return {
      email: "",
      joinImg: require("@/assets/Images/joinImg.jpg"), // 我要加入的地址
      phoneTip: "",
      joinForm: { // 要传给后台的表单数据
        phone: "",
        sms: "",
        name: "",
        idCard: "",
        selectedCity: "",
        selectedJob: "",
      },
      
      showPicker1: false,
      citys: [
        {
          values: Object.keys(Citys),
          className: "cityColumn1"
        },
        {
          values: Citys["北京市"],
          className: "cityColumn2"
          //defaultIndex: 0
        }
      ],
      showPicker2: false,
      jobs: [],
      checked: false
    };
  },

  components: {
    ValidationProvider,
    ValidationObserver
  },

  // 钩子函数获取职业信息
  created() {
    this.fetchPopupData();
  },

  methods: {
    onConfirmCity(value) {
      this.joinForm.selectedCity = value[0] + " - " + value[1];
      this.showPicker1 = false;
    },
    onChangeCity(picker, values) {
      picker.setColumnValues(1, Citys[values[0]]);
    },

    onConfirmJob(value) {
      this.joinForm.selectedJob = value;
      this.showPicker2 = false;
    },

    // 如果手机号码不为0位或11位，出现错误提示
    handlePhoneLength() {
      const len = this.joinForm.phone.length;
      if (len == 0 || len == 11) {
        this.phoneTip = "";
      } else {
        this.phoneTip = "手机号格式错误";
      }
    },

    // 组装职业弹出选择框数据
    fetchPopupData() {
      // 获取后台维护的职业数据
      joinApi.getJobs().then(response => {
        const resp = response.data;
        if (resp.flag) {
          // 查询成功
          for (const item of resp.data) {
            this.jobs.push(item.code);
          }
        }
      });
    },

    // 加盟须知弹出框
    showDialog() {
      this.$dialog
        .alert({
          title: "加盟须知",
          messageAlign: "left",
          message: `提交资料成功后你将成为赏金猎人一员，可通过赏金猎人平台为群创光电输送人力，赚取推荐奖金。
          推荐人员入职，需对推荐人员进行追踪，人员入职满1个月即可获得推荐奖金。
          推荐奖金发放规则：依据招募宣传政策
          推荐奖金发放方式：银行卡打款（需进行银行卡绑定）
          推荐奖金结算日期：每月1日
          推荐奖金发放时间：每月10日
          注：被推荐人入职日期在N月1日~31日，入职满一个月后，奖金将于(N+2)月10日进行发放。`.trimMultiSpace()
        })
        .then(() => {
          //点击确定按钮时做什么？
        })
        
    },

    // 提交表单
    submitForm(){
      // 先判断卡关
      if(this.phoneTip != ""){
        this.$toast(this.phoneTip);
      }
      for(let prop in this.joinForm){
        if(!this.joinForm[prop]){
          this.$toast(prop + "不能为空");
          
        }
      }
      // 表单验证资源：https://blog.csdn.net/qq_28218253/article/details/100559201
    }
  }
};
</script>

<style scoped>
.submitForm {
  /* background-color: rgb(255, 255, 255, 0.8); */
  /* height: 50%; */
  padding: 0.5vh 5vw 0.5vh 8vw;
  /* border-radius: 20px; */
}
.van-checkbox {
  text-decoration: underline;
  float: right;
  margin: 1vh 0;
  font-size: 0.8rem;
}
.btnGroup .van-button {
  display: block;
  width: 70%;
  margin: 1vh auto;
}

</style>