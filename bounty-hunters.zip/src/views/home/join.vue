<template>
  <div>
    <div align="center" style="background-color:red;">
      <van-image
      height="180"
      radius="15"
      src = "https://img.yzcdn.cn/vant/apple-2.jpg"
      />
    </div>

    <div class="submitForm">
      <!-- 输入手机号码，调起手机号键盘 -->
      <van-cell-group>
        <van-field
          v-model="phone"
          required
          label="手机号码："
          placeholder="请输入手机号"
          error-message="手机号格式错误"
        />
      </van-cell-group>
      <!-- 输入短信验证码 -->
      <van-field
        v-model="sms"
        required
        center
        clearable
        label="短信验证码："
        placeholder="请输入短信验证码"
      >
        <van-button slot="button" size="small" type="primary">发送验证码</van-button>
      </van-field>
      <!-- 输入人员姓名 -->
      <van-field v-model="name" required label="人员姓名：" placeholder="请输入姓名"/>
      <!-- 输入身份证号码 -->
      <van-field v-model="idCard" required label="身份证号：" placeholder="请输入身份证号（X需要大写）"/>

      <!-- 允许输入整数，调起数字键盘 -->
      <!-- <van-field v-model="digit" type="digit" label="整数" /> -->
      <!-- 允许输入数字，调起全键盘 -->
      <!-- <van-field v-model="number" type="number" label="数字" /> -->
      <!-- 输入密码 -->
      <!-- <van-field v-model="password" type="password" label="密码" /> -->

      <!-- 所在地区 -->
      <van-field
        readonly
        clickable
        required
        label="所在地区："
        :value="selectedCity"
        placeholder="-请选择-"
        @click="showPicker1 = true"
      />
      <van-popup v-model="showPicker1" position="bottom">
        <van-picker
          show-toolbar
          :columns="citys"
          @cancel="showPicker1 = false"
          @confirm="onConfirmCity"
          @change="onChangeCity"
        />
      </van-popup>

      <!-- 职业 -->
      <van-field
        readonly
        clickable
        label="职业："
        :value="selectedJob"
        placeholder="-请选择-"
        @click="showPicker2 = true"
      />
      <van-popup v-model="showPicker2" position="bottom">
        <van-picker
          show-toolbar
          :columns="jobs"
          @cancel="showPicker2 = false"
          @confirm="onConfirmJob"
        />
      </van-popup>

      <!-- 同意框 -->
      <van-checkbox v-model="checked" shape="square">
        <span>我已阅读并知晓加盟须知</span>
      </van-checkbox>
    </div>

    <div class='btnGroup'>
        <van-button type="info">提交</van-button>
        <van-button color="#00CCFF" to="/home">不了，我再逛逛</van-button>
    </div>
  </div>
</template>

<script>
const citys = {
  '浙江': ['杭州', '宁波', '温州', '嘉兴', '湖州'],
  '福建': ['福州', '厦门', '莆田', '三明', '泉州'],
  '江苏': ['苏州','南京','无锡']
};

export default {
  data() {
    return {
      phone: '',
      sms: '',
      name: '',
      idCard: '',
      digit: '',
      number: '',
      password: '',
      selectedCity: '',
      showPicker1: false,
      citys:[
        {
          values: Object.keys(citys),
          className: 'cityColumn1'
        },
        {
          values: citys['浙江'],
          className: 'cityColumn2',
          //defaultIndex: 0
        }
      ],
      selectedJob: '',
      showPicker2: false,
      jobs: ['学生', '老师', '其他'],
      checked: false
    };
  },

  components: {},

  methods: {
    onConfirmCity(value) {
      this.selectedCity = value[0] + " - " +value[1];
      this.showPicker1 = false;
    },
    onChangeCity(picker, values) {
      picker.setColumnValues(1, citys[values[0]]);
    },

    onConfirmJob(value) {
      this.selectedJob = value;
      this.showPicker2 = false;
    },
  }
};
</script>

<style scoped>
.submitForm {
  /* background-color: rgb(255, 255, 255, 0.8); */
  /* height: 50%; */
  padding: 20px 20px 20px 30px;
  border-radius: 20px;
}
.van-checkbox{
  text-decoration: underline;
  float: right;
  margin: 10px 0 20px 0;
  font-size: 0.8rem;
}

.btnGroup .van-button{
  display:block;
  width:70%;
  margin:10px auto
}
</style>