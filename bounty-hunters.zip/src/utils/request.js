import axios from "axios"

// 按需导入 ElementUI 组件 实现Loading加载数据和异常统一处理
import { Loading, Message } from 'element-ui';

// 加载数据时打开和关闭动效对象
const loading = {
    // 注意：loadingInstance 实例采用单例模式创建，防止响应异常时频繁切换路由时加载动效重复创建
    loadingInstance : null, // Loading实例

    open(){ // 打开加载
        console.log('加载中', this.loadingInstance);
        if(this.loadingInstance === null) { // 创建单例, 防止切换路由重复加载
            this.loadingInstance = Loading.service({
                text: "拼命加载中...",
                target: '.main', // 效果显示区域, div.main在AppMain.vue文件中
                background: 'rgba(0, 0, 0, 0.5)' // 加载效果
            })
        }
    },

    close(){ // 关闭加载
        if(this.loadingInstance !== null) {
            this.loadingInstance.close();
        }
        this.loadingInstance = null // 关闭后实例重新赋值null, 下次让它重新创建
    }
}

// 学习理解路线：
// 第一步：不封装axios对象，直接异步请求数据
// axios.get('/db.json').then(response => {
//     console.log("get1", response.data);
// }).catch(error => {
//     console.log(error);
// })


// 第二步：手动创建一个axios对象, 用于设置相关属性和拦截器，参考: https://github.com/axios/axios#creating-an-instance
const request = axios.create({
    // 请求配置参考: https://github.com/axios/axios#request-config
    // 根据不同环境设置 baseURL, 最终发送请求时的URL为: baseURL + 发送请求时写URL ,
    // 比如设置baseURL: '/dev-api'， 使用request.get('/test')时, 最终发送请求是: /dev-api/test
    //baseURL: '/', // 默认是 /

    //baseURL: '/dev-api',
    // 使用根目录下的 .env.development 与 .env.production 中配置 VUE_APP_BASE_API
    baseURL: process.env.VUE_APP_BASE_API, 

    timeout: 5000 // 请求超时，设置5000ms
})

// 发送请求后设置拦截器（之后实现具体功能）
// Add a request interceptor
request.interceptors.request.use(function (config) {
    // Do something before request is sent
    loading.open(); //打开加载效果
    return config;
}, function (error) {
    // Do something with request error
    loading.close(); //关闭加载效果
    return Promise.reject(error);
});

// 接收请求前设置拦截器（之后实现具体功能）
// Add a response interceptor
request.interceptors.response.use(function (response) {
    // Do something with response data
    loading.close(); //关闭加载效果

    const resp = response.data;
    // 如果后台响应状态码不是 2000 , 说明后台服务有异常,统一可在此处处理
    if(resp.code !== 2000){
        Message({
            message: resp.message || '系统异常',
            type: 'warning',
            duration: 5 * 1000 // 停留时长
        })
    }

    return response;
}, function (error) {
    // Do something with response error
    loading.close(); //关闭加载效果

    // 当请求接口出错时, 进行弹出错误提示, 如 404, 500, 请求超时
    console.log('response error', error.response.status)
    Message({
        message: error.message,
        type: 'error',
        duration: 5 * 1000 // 停留时长
    })
    
    return Promise.reject(error);
});


// 自己封装好axios之后，接着去api/test.js下接着看代码
export default request // 导出 axios 对象