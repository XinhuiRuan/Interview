/*
Vant 中的样式默认使用px作为单位，如果需要使用rem单位，推荐使用以下两个工具：
postcss-pxtorem 是一款 postcss 插件，用于将单位转化为 rem
lib-flexible 用于设置 rem 基准值

PostCSS 配置
下面提供了一份基本的 postcss 配置，可以在此配置的基础上根据项目需求进行修改
*/

module.exports = {
  // plugins: {
  //   'autoprefixer': {
  //     browsers: ['Android >= 4.0', 'iOS >= 8']
  //   },
  //   'postcss-pxtorem': {
  //     rootValue: 37.5,
  //     propList: ['*']
  //   }
  // }
}