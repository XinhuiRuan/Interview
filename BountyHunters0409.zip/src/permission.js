/*
权限校验：
通过router路由前置钩子函数 beforeEach() ，
在跳转路由前进行拦截判断是否已经登录，
如果已登录，则进行路由跳转，如果没有则回到登录页
*/

import router from './router'
import store from './store'
import util from '@/utils/weixin.js'
/*
前置路由钩子函数
to ：即将要进入的目标路由对象
from ：当前导航正要离开的路由对象
next : 调用该方法，进入目标路由
*/
router.beforeEach((to, from, next) => {
    if (to.path == '/home/apply') { // 进入自主推荐页面时不需要获取微信信息，直接进入
        next()
    } else {

        const code = util.getUrlParam("code") // 截取url上的code ,可能没有,则返回''空字符串

        if (code == "" && process.env.NODE_ENV == "production") {
            // 生产环境下去取微信code
            let redirectUrl = `${window.location.href}?t=${util.getRandom(1, 51)}`;
            redirectUrl = encodeURIComponent(redirectUrl)
            const appid = process.env.VUE_APP_APPID
            window.location.href = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=${appid}&redirect_uri=${redirectUrl}&response_type=code&scope=snsapi_userinfo&state=123&connect_redirect=1#wechat_redirect`
        } else {

            // 方法：判断是否需要进入 我要加入(join)页面
            function IsToJoinPage(flag) {
                /* 当即将进入的路由是三大主页的子页面时，
                    如果没有注册，则跳转进入 我要加入(join)页面；否则正常跳转
                */
                // let mainPages = ['home','answer','member']
                let pathArr = to.path.split('/').filter(item => item != '');
                // if (pathArr.length > 1 && mainPages.indexOf(pathArr[0]) != -1) {
                if (pathArr.length > 1) {
                    if (pathArr[1] != "join" && !flag) {
                        return true
                    }
                }
                return false
            }

            const weixinId = store.state.hunter.weixinId // 用于判断是否第一次进入页面
            if (!weixinId) { // 进入首页时，将code返回给后台，得到猎人信息
                store.dispatch("InitRegisteredInfo", code).then(response => {
                    if (IsToJoinPage(response) == true) {
                        next({
                            path: '/home/join',
                            replace: true,
                            query: {
                                toPath: to.path
                            }
                        })
                    }
                    else {
                        next()
                    }
                })
            }
            else {
                const registeredId = store.state.hunter.registeredId // 得到store存的注册为賞金猎人的id
                if (IsToJoinPage(registeredId) == true) {
                    next({
                        path: '/home/join',
                        replace: true,
                        query: {
                            toPath: to.path
                        }
                    })
                }
                else {
                    next()
                }
            }

        }

    }
})
