import Vue from 'vue'
import Vuex from 'vuex'
import hunter from './modules/hunter'

Vue.use(Vuex)

const store = new Vuex.Store({
    modules: {
        hunter
    }
})

export default store