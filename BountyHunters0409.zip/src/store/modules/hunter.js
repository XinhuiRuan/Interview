import { initRegisteredInfo } from '@/api/login'
import joinApi from "@/api/join"

const hunter = {
    state: {
         registeredId: '',
         weixinId: '',
        //  registeredId: '316469d2-b8e6-4c4e-9f4e-84cc1e6de7f5', // 得到赏金猎人注册的ID        
        //  weixinId: 'obJvmst6XeN6c_c_dCt4fe_2T8Ok', // 用户微信ID 
        weixinSelfie: '', // 用户微信头像地址  
        weixinName: '', // 用户微信名称    
    },

    mutations: {
        SET_REGISTEREDID(state, registeredId) {
            state.registeredId = registeredId;
        },
        
        SET_WEIXINID(state, weixinId) {
            state.weixinId = weixinId;
        },

        SET_WEIXINSELFIE(state, weixinSelfie) {
            state.weixinSelfie = weixinSelfie;
        },

        SET_WEIXINNAME(state, weixinName) {
            state.weixinName = weixinName;
        },
    },

    actions: {
        // 第一次从首页进入，根据微信的code从后台得到猎人加盟id、微信id、微信名和微信头像图片链接
        InitRegisteredInfo({ commit, state }, code) {
            return new Promise((resolve, reject) => {
                initRegisteredInfo(code).then(response => {
                    let isRegistered = false
                    const resp = response.data
                    if (resp.flag) {
                        const infos = resp.data
                        if(infos.hunter_id) {
                            // 是已加盟的猎人
                            isRegistered = true
                            commit("SET_REGISTEREDID", infos.hunter_id)
                        }
                        commit("SET_WEIXINID", infos.openid)
                        commit("SET_WEIXINSELFIE", infos.headimgurl)
                        commit("SET_WEIXINNAME", infos.nickname)
                    }
                    resolve(isRegistered)
                })
            })
        },

        Join({ commit }, form){
            // 提交表单给后台进行验证是否正确
            // resolve 触发成功处理，reject 触发异常处理
            return new Promise((resolve, reject) => {
                joinApi.addHunter(form).then(response => {
                    const resp = response.data
                    commit("SET_REGISTEREDID", resp.data.id) // 获取新的猎人注册id
                    resolve(resp)
                });
            })
        }
    }
}

export default hunter