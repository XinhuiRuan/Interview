import request from "@/utils/request"

export default{
    // 得到会员中心首页的信息
    getMemberMainInfo(id){
        return request({
            url: `/Member?Hunter_id=${id}`,
            method: "get"
        })
    },

    // 得到 会员中心 -> 我的资料 页面的信息
    getMemberPersonalInfo(id){
        return request({
            url: `PersonalInfo?Hunter_id=${id}`,
            method: "get"
        })
    },

    // 得到 会员中心 -> 我的资料 -> 加盟函 页面的信息
    getJoinLetterInfo(id){
        return request({
            url: `/JoinLetter?Hunter_id=${id}`,
            method: "get"
        })
    },
}