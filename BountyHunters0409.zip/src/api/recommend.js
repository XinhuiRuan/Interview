import request from "@/utils/request"

export default{
    // 新增被推荐人
    addRecommended(infos){
        return request({
            url: `/Recommended`,
            method: "post",
            data: infos
        })
    },

    // 得到推荐须知里的用户维护信息
    getRecommendNotice(){
        return request({
            url: `/RecommendNotice`,
            method: "get"
        })
    },

    // 得到被推荐人的信息
    getRecommendedInfos(id){
        return request({
            url: `/QRecommended?Reuruit_id=${id}`,
            method: "get"
        })
    },
}