import request from "@/utils/request"

// 获取注册的赏金猎人注册信息
export function initRegisteredInfo(code) {
    return request({
        url: `/WxLogin`, // 注意是反单引号 ``
        method: "post",
        data: {
            code
        }
    })
}