import request from "@/utils/request"

export default{
    // 赏金猎人根据ID查询得到收集的简历列表
    getResumes(id){
        return request({
            url: `/Resumes?Hunter_id=${id}`,
            method: "get"
        })
    },
}