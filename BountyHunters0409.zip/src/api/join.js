import request from "@/utils/request"

export default{
    // 得到下拉选择的职业数据
    getJobs(){
        return request({
            url: `/jobs`,
            method: "get"
        })
    },

    // 新增赏金猎人
    addHunter(infos){
        return request({
            url: '/join',
            method: "post",
            data: infos
        })
    },

    // 发送验证码
    sendSms(telephone){
        return request({
            url: `/VerifiCode?telephone=${telephone} `,
            method: "get"
        })
    },
}