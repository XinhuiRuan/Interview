import request from "@/utils/request"

export default{
    // 得到问题回答
    getAnswers(){
        return request({
            url: `/answers`,
            method: "get",           
        })
    },
}