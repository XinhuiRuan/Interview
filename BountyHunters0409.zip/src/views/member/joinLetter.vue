<template>
  <div class v-show="show">
    <div class="logo">
      <img id="logo" :src="logoUrl" alt="">
    </div>
    <div class="title">
      <h3>加盟函</h3></div>
    <div class="content">
      <p class="part1">
        <span>致 {{name}}：</span></p>
      <p class="part2">
        <span>现通知您正式加盟宁波群志光电有限公司赏金猎人项目，成为赏金猎人一员，可为我司输送人力，获取推荐奖金。</span>
      </p>
      <p class="part3">
          <span>宁波群志光电有限公司</span>
          <br>
          <span v-text="joinDate"></span>
      </p>
    </div>
    
    <!-- <van-button color="#00CCFF" :to="$route.query.back ? $route.query.back : '/home'">关闭</van-button> -->
  </div>
</template>

<script>
import memberApi from "@/api/member";

export default {
  components: {},

  data() {
    return {
        logoUrl: require('@/assets/Images/INNOLUX.png'),
        name: "",
        joinDate: "",
        show: false
    };
  },

  created(){
    this.fetchJoinLetteInfo()
  },

  mounted() {
    document.getElementById("logo").onload = () => {
      this.show = true // 当图片加载完再显示页面
    }
  },

  methods: {
    // 得到加盟函的姓名和加盟日期
    fetchJoinLetteInfo(){
        const registeredId = this.$store.state.hunter.registeredId; // 得到赏金猎人的id
        memberApi.getJoinLetterInfo(registeredId).then(response => {
            const resp = response.data;
                if (resp.flag) {
                    const data = resp.data;
                    this.name = data.name;
                    this.joinDate = data.registration;
                }else{
                    this.$toast.fail(resp.message);
                }
          })         
    }
  },
};
</script>

<style scoped>
span{
  font-size: 0.9rem;
  /* font-weight:bold; */
}

.logo{
  margin-top: 10%;
  text-align: center;
}

.title{
  text-align: center;
}

.content{
  padding: 0 10%;
}
.content .part2{
  text-indent: 2rem;
  text-align: justify;
  line-height: 1.5rem;
}
.content .part3{
  text-align: right;
}

.van-button {
  display: block;
  width: 50%;
  margin: 10% auto 0vh auto;
}
</style>