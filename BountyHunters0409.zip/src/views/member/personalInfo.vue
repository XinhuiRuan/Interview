<template>
  <div>
    <div class="infoDiv" >
      <van-cell-group>
        <van-cell title="我的姓名" :value="name" />
        <van-cell title="联系号码" :value="telephone" />
        <van-cell title="身份证号" :value="empid" />
        <van-cell title="所在地区" :value="area" />
      </van-cell-group>

      <van-cell-group>
        <van-cell title="资质认证" is-link @click="toJoinLetter" />
        <van-cell title="个人专属二维码" @click="createQRCode()">
          <!-- 使用 right-icon 插槽来自定义右侧图标 -->
          <van-icon
            slot="right-icon"
            name="qr"
            size="20px"
            color="#969799"
            style="line-height: inherit;"
          />
          <van-icon 
            size="16px"
            color="#969799"
            slot="right-icon"
            name="arrow"
            style="line-height: inherit;"
          />
        </van-cell>
      </van-cell-group>

      <div id="code" style="display: none">
        <canvas id="canvas"></canvas>
      </div>
    </div>
  </div>
</template>

<script>
import { ImagePreview } from 'vant';
import QRCode from "qrcode"; //引入生成二维码，如果有很多页面使用的话可以在main中引入，挂载在全局；
import memberApi from "@/api/member";

export default {
  data() {
    return {
      name: "",
      telephone: "",
      empid: "",
      area: ""
    };
  },

  components: {
    QRcode: QRCode //注册生成二维码组件
  },

  created() {
    this.fetchMemberPersonalInfo();
  },

  methods: {
    // 后台查询得到在 会员中心 -> 我的资料 页面需要的数据
    fetchMemberPersonalInfo() {
      const registeredId = this.$store.state.hunter.registeredId; // 得到赏金猎人的id
      memberApi.getMemberPersonalInfo(registeredId).then(response => {
        const resp = response.data;
        if (resp.flag) {
          const data = resp.data;
          this.name = data.name;
          this.telephone = data.telephone;
          this.empid = data.empid;
          this.area = data.area;
        } else {
          this.$toast.fail(resp.message);
        }
      });
    },

    // 前往加盟函页面
    toJoinLetter() {
      this.$router.push({
        path: "/member/personalInfo/joinLetter",
        // query: {
        //   back: "/member/personalInfo" // 加盟函点击确认后所需返回的路由地址
        // }
      });
    },

    // 生成二维码的方法
    createQRCode() {
      // 设置赏金猎人专属的二维码url
      const registeredId = this.$store.state.hunter.registeredId; // 得到赏金猎人的id
      let url = `http://ngbapp.innolux.com/InnoluxBountyHunters/index.html#/home/apply?id=${registeredId}`

      var canvas = document.getElementById("canvas"); //获取到canvas

      var code = document.getElementById("code"); //获取到code容器
      QRCode.toCanvas(canvas, url, error => {
        if (error) console.error(error);
        //console.log("success!");
      });

      var image = new Image(); //实例一个img
      image.src = canvas.toDataURL("image/png"); //转换成base64格式路径的png图片
      // image.style.width = "50%"; //设置样式

      code.appendChild(image); //添加到code 容器中
      canvas.style.display = "none"; //隐藏掉canvas

      //image.loaded
      // 用图片预览方式展示二维码
      ImagePreview({
        images: [
          image.src
        ],
        showIndex: false
      });
    }
  }
};
</script>

<style scoped>
span {
  color: #606266;
}

.infoDiv{
  background: #F5F5F5;
}

.van-cell-group{
  margin-bottom: 2vh;
  font-size: 0.8rem;
}

</style>