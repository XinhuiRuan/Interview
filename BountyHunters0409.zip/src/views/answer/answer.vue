<template>
  <div class v-show="show">
    <div class="imgDiv" align="center">
      <van-image fit="fill" :src="answerImg" />
    </div>

    <div class="commonFont" align="center">
      <span>
        咨询电话：<span v-text="hotline"></span>
      </span>
      <a :href="'tel://'+hotline" class="el-icon-phone" style="margin-left: 1%;">
        <!-- <van-icon name="phone" color="blue" size="1rem"/> -->
      </a>
    </div>

    <div class="answerDiv loadingArea">
      <!-- 循环遍历问题回答 -->
      <van-panel v-for="(item,index) in answers" :key="index" :title="item.question">
        <span>{{item.answer}}</span>
      </van-panel>
    </div>
  </div>
</template>

<script>
import answersApi from "@/api/answers";

export default {
  components: {},

  data() {
    return {
      answerImg: require("@/assets/Images/answerImg.jpg"), // 答疑解惑图片的地址
      answers: [],
      hotline: "158-8888-8888",
      show: false
    };
  },

  // 钩子函数获取职业信息
  created() {
    this.fetchAnswerData();
  },

  mounted() {
      let img = document.getElementsByClassName("van-image")[0].childNodes[0];//图片
      img.onload = () => {
        this.show = true
      }
  },

  methods: {
    // 获取后台维护的答疑解惑
    fetchAnswerData() {
      // 获取后台维护的问题回答
      answersApi.getAnswers().then(response => {
        const resp = response.data;
        if (resp.flag) {
          // 查询成功
          for (const item of resp.data) {
            this.answers.push({
              question: item.question,
              answer: item.answer
            });
          }
        }
      });
    }
  }
};
</script>

<style scoped>
.commonFont{
  margin-top: 1.5vh;
}

.van-panel {
  margin: 1.5vh 1vw;
  background: #f5f5f5;
  box-shadow: 0 0.5vh 0.5vh 0 #a9a9a9;
}
.van-cell {
  background: #f5f5f5;
  font-size: 0.9rem;
  font-weight: bold;
  padding: 1vh 3vw;
  border-bottom: 0.2vh solid #a9a9a9;
}
.van-panel__content {
  padding: 1vh 3vw;
  font-size: 0.8rem;
  text-align: justify;
}

.commonFont {
  font-size: 0.8rem;
}

.answerDiv:after {
  content: "";
  height: 50px;
  display: block;
}
</style>