<template>
  <div>
    <div class="notice">
      <div>1.填写面试申请信息请输入推荐人联系方式，即信息发布者联系方式。</div>
      <div>2.填写相应个人信息，并进行面试时间选择后，即可进行面试申请。</div>
    </div>
    <recommend :isSubComponent="true" :isRecruitment="true" :propBhMobile="bhMobile"></recommend>   
  </div>
</template>

<script>
import Recommend from "@/views/home/recommend.vue";
import memberApi from "@/api/member";

export default {
  data() {
    return {
      bhMobile: ''
    };
  },

  components: {
    Recommend
  },

  created(){
    const bhId = this.$route.query.id
    if(bhId){
      this.getHunterPhone(bhId)
    }
  },

  methods: {
    // 根据二维码上的赏金猎人id得到手机号码
    getHunterPhone(bhId){
      memberApi.getMemberPersonalInfo(bhId).then(response => {
        const resp = response.data;
        if (resp.flag) {
          this.bhMobile = resp.data.telephone;
        } else {
          this.$toast.fail(resp.message);
        }
      });
    }
  }
};
</script>

<style scoped>
.notice {
  font-size: 0.8rem;
  text-align: justify;
  color: #606266;
  line-height: 1.5rem;
  padding: 2vh 8vw;
}
</style>