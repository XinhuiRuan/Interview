<template>
  <div v-show="show">
    <!-- van-image的fit属性：
        contain	保持宽高缩放图片，使图片的长边能完全显示出来
        cover	保持宽高缩放图片，使图片的短边能完全显示出来，裁剪长边
        fill	拉伸图片，使图片填满元素
        none	保持图片原有尺寸
        scale-down	取none或contain中较小的一个
    -->
    <div class="imgDiv" align="center">
      <van-image fit="fill" :src="joinImg" />
    </div>

    <div class="submitForm">
      <ValidationObserver ref="form">
        <!-- 输入手机号码，调起手机号键盘 -->
        <ValidationProvider rules="required|mobile" name="telephone" v-slot="{ errors }"> 
          <van-field
            autofocus
            v-model.trim="joinForm.telephone"
            required
            clearable
            type="tel"
            maxlength="11"
            label="手机号码："
            placeholder="请输入手机号码"
            :error-message="errors[0]"
          >
            <van-button
              :disabled=" joinForm.telephone.length == 11 ? hasSend : true"
              slot="button"
              size="small"
              type="primary"
              @click="SendSms"
              :text="smsBtnMsg"
            />
          </van-field>
        </ValidationProvider>

        <!-- 输入短信验证码 -->
        <ValidationProvider rules="required" name="code">
          <van-field
            v-model.trim="joinForm.code"
            required
            center
            clearable
            type="tel"
            label="短信验证码："
            placeholder="请输入短信验证码"
          ></van-field>
        </ValidationProvider>

        <!-- 输入人员姓名 -->
        <ValidationProvider rules="required" name="name">
          <van-field
            v-model.trim="joinForm.name"
            required
            clearable
            label="人员姓名："
            placeholder="请输入姓名"
          />
        </ValidationProvider>

        <!-- 输入身份证号 -->
        <ValidationProvider rules="required|idCard" name="empid" v-slot="{ errors }">
          <van-field
            v-model.trim="joinForm.empid"
            required
            clearable
            maxlength="18"
            label="身份证号："
            placeholder="请输入身份证号（X需要大写）"
            :error-message="errors[0]"
          />
        </ValidationProvider>

        <!-- <van-field
        readonly
        required
        label="身份证号："
        placeholder="请输入身份证号（X需要大写）"
        :value="joinForm.empid"
        @touchstart.native.stop="empIdDialogShow = true"
      />
      <van-number-keyboard
        close-button-text="完成"
        extra-key="X"
        v-model="joinForm.empid"
        :show="empIdDialogShow"
        @blur="empIdDialogShow = false"
        />-->

        <!-- 所在地区 -->
        <ValidationProvider rules="required" name="area">
          <van-field
            readonly
            clickable
            required
            label="所在地区："
            :value="joinForm.area"
            placeholder="-请选择-"
            @click="showPicker1 = true"
          />
        </ValidationProvider>
        <van-popup v-model="showPicker1" position="bottom">
          <van-picker
            show-toolbar
            :columns="citys"
            @cancel="showPicker1 = false"
            @confirm="onConfirmCity"
            @change="onChangeCity"
          />
        </van-popup>

        <!-- 职业，加个空的ValidationProvider，因为这个验证器有个Bug，所以统一不显示van-field原来的下划线 -->
        <ValidationProvider>
        <van-field
          readonly
          clickable
          label="职业："
          :value="joinForm.occupation"
          placeholder="-请选择-"
          @click="showPicker2 = true"
        />
        </ValidationProvider> 

        <van-popup v-model="showPicker2" position="bottom">
          <van-picker
            show-toolbar
            :columns="jobs"
            @cancel="showPicker2 = false"
            @confirm="onConfirmJob"
          />
        </van-popup>

        <!-- 同意框 -->
        <van-checkbox v-model="checked" shape="square" @click="showJoinDialog">
          <span>我已阅读并知晓加盟须知</span>
        </van-checkbox>

        <div class="btnGroup">
          <van-button type="info" @click="handleJoinForm">提交</van-button>
          <!-- <van-button color="#00CCFF" to="/home">不了，我再逛逛</van-button> -->
        </div>
      </ValidationObserver>
    </div>
  </div>
</template>

<script>
import joinApi from "@/api/join";
import Citys from "@/assets/citys";
import { ValidationProvider, ValidationObserver } from "vee-validate";

export default {
  data() {
    return {
      show: false,
      joinImg: require("@/assets/Images/joinImg.jpg"), // 我要加入图片的地址
      joinForm: {
        // 要传给后台的表单数据
        appid: this.$store.state.hunter.weixinId,
        telephone: "",
        code: "", // 验证码
        name: "",
        empid: "",
        area: "",
        occupation: ""
      },
      smsBtnMsg: "发送验证码", // 发送验证码按钮显示的信息
      hasSend: false, // 是否在发送验证码状态
      countTime: 60,
      showPicker1: false,
      citys: [
        {
          values: Object.keys(Citys),
          className: "cityColumn1"
        },
        {
          values: Citys["北京市"],
          className: "cityColumn2"
          //defaultIndex: 0
        }
      ],
      showPicker2: false,
      jobs: [],
      checked: false,
      empIdDialogShow: false
    };
  },

  components: {
    ValidationProvider,
    ValidationObserver
  },

  // 钩子函数获取职业信息
  created() {
    this.initalData();
  },

  mounted() {
      let img = document.getElementsByClassName("van-image")[0].childNodes[0];//图片
      img.onload = () => {
        this.show = true
      }
  },

  methods: {
    // 判断用户是否已经注册，无需重复注册；没有注册过，从后台获取职业弹出选择框的数据
    initalData() {
      const registeredId = this.$store.state.hunter.registeredId; // 得到赏金猎人的id
      if (registeredId) {
        // 已注册过，弹出提示框，点击确认回到主页
        this.$dialog
          .alert({
            messageAlign: "center",
            message: `<span style="color:#A9A9A9;font-weight:bold;font-size:0.9rem;">您已加盟，无需再次加盟</span>`
          })
          .then(() => {
            // 点击确认回到首页
            this.$router.push("/home");
          });
      } else {
        // 第一次注册，获取后台维护的职业数据
        joinApi.getJobs().then(response => {
          const resp = response.data;
          if (resp.flag) {
            // 查询成功
            for (const item of resp.data) {
              this.jobs.push(item.code);
            }
          }
        });
      }
    },

    // 发送验证码
    SendSms() {
      this.hasSend = true;
      let that = this;
      // 倒计时方法
      function countdownFunc() {
        that.countTime -= 1;
        that.smsBtnMsg = that.countTime + "秒后重新获取";
      }
      countdownFunc();
      var timing = setInterval(countdownFunc, 1000);

      setTimeout(() => {
        // 充重置数据
        this.hasSend = false;
        this.countTime = 60;
        this.smsBtnMsg = "发送验证码";
        clearInterval(timing); // 清除定时器
      }, 60 * 1000);
      // 发送电话号码到后台
      joinApi.sendSms(this.joinForm.telephone).then(response => {
        const resp = response.data;
        if (!resp.flag) {
          this.$toast(resp.message);
          return;
        }
      });
    },

    onConfirmCity(value) {
      this.joinForm.area = value[0] + " - " + value[1];
      this.showPicker1 = false;
    },
    onChangeCity(picker, values) {
      picker.setColumnValues(1, Citys[values[0]]);
    },

    onConfirmJob(value) {
      this.joinForm.occupation = value;
      this.showPicker2 = false;
    },

    // 加盟须知弹出框
    showJoinDialog() {
      if (!this.checked) {
        this.$dialog.alert({
          title: "加盟须知",
          messageAlign: "left",
          message: `提交资料成功后你将成为赏金猎人一员，可通过赏金猎人平台为群创光电输送人力，赚取推荐奖金。
            推荐人员入职，需对推荐人员进行追踪，人员入职满1个月即可获得推荐奖金。
            推荐奖金发放规则：依据招募宣传政策
            推荐奖金发放方式：银行卡打款（需进行银行卡绑定）
            推荐奖金结算日期：每月1日
            推荐奖金发放时间：每月10日
            注：被推荐人入职日期在N月1日~31日，入职满一个月后，奖金将于(N+2)月10日进行发放。`.trimMultiSpace()
        });
      }
    },

    // 验证成功，提交表单
    submitJoinForm() {
      this.$store.dispatch("Join", this.joinForm).then(response => {
        if (response.flag) {
          this.$toast.success(response.message);
          this.$router.push({
            path: "/home/joinLetter"
            // query: {
            //   back: this.$route.query.toPath // 加盟函点击确认后所需返回的路由地址
            // }
          });
        } else {
          this.$toast.fail(response.message);
        }
      });
    },

    // 处理表单
    handleJoinForm() {
      let that = this;
      this.$refs.form.validate().then(res => {
        if (res) {
          // 验证成功
          if (!that.checked) {
            that.$toast("请阅读加盟须知")
            return;
          }
          if (!that.joinForm.appid) {
            that.$toast("提交失败，没有获取到微信信息");
            return;
          }

          that.submitJoinForm() // 提交表单
        }else{
          that.$toast("请填写正确信息")
        }
      });
    }
  }
};
</script>

<style scoped>
.van-field{
  border-bottom: 0.2vh solid #ebedf0;
}

.submitForm {
  /* background-color: rgb(255, 255, 255, 0.8); */
  /* height: 50%; */
  padding: 0.5vh 5vw 0 8vw;
  /* border-radius: 20px; */
}
.van-checkbox {
  text-decoration: underline;
  float: right;
  margin: 1.5vh 0 2vh 0;
  font-size: 0.8rem;
}
.btnGroup .van-button {
  display: block;
  width: 75%;
  margin: 1.5vh auto;
}
</style>