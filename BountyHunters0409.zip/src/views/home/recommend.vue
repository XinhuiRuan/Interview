<template>
  <div v-show="show">
    <div class="imgDiv" align="center" v-if="!isSubComponent">
      <van-image fit="fill" :src="recommendImg" />
    </div>

    <div class="commonFont" align="center" v-if="!isSubComponent">
      <span>推荐人：{{recommendName}}</span>
    </div>
    <div class="commonFont" align="center" v-if="!isSubComponent">
      <span>被推荐人</span>
    </div>

    <div class="submitForm">
      <ValidationObserver ref="form">
        <!-- 输入推荐人手机号码 -->
        <ValidationProvider
          v-if="isRecruitment"
          rules="required|mobile"
          name="telephone"
          v-slot="{ errors }"
        >
          <van-field
            v-model.trim="recommendForm.bhMobile"
            required
            clearable
            type="tel"
            maxlength="11"
            label="推荐人："
            placeholder="请输入手机号"
            :error-message="errors[0]"
          />
        </ValidationProvider>

        <!-- 输入人员姓名 -->
        <ValidationProvider rules="required" name="name">
          <van-field
            v-model.trim="recommendForm.name"
            required
            clearable
            label="人员姓名："
            placeholder="请输入姓名"
          />
        </ValidationProvider>

        <!-- 输入手机号码，调起手机号键盘 -->
        <ValidationProvider rules="required|mobile" name="telephone" v-slot="{ errors }">
          <van-field
            v-model.trim="recommendForm.telephone"
            required
            clearable
            type="tel"
            maxlength="11"
            label="手机号码："
            placeholder="请输入手机号"
            :error-message="errors[0]"
          />
        </ValidationProvider>

        <!-- 输入身份证号 -->
        <ValidationProvider
          v-if="!isRecruitment"
          rules="required|idCard"
          name="empid"
          v-slot="{ errors }"
        >
          <van-field
            v-model.trim="recommendForm.empid"
            clearable
            required
            maxlength="18"
            label="身份证号："
            placeholder="请输入身份证号（X需要大写）"
            :error-message="errors[0]"
            class="noBorder"
          />
        </ValidationProvider>

        <!-- 面试日期 -->
        <van-cell-group>
          <van-cell
            required
            title="面试日期："
            is-link
            :value="recommendForm.interviewdate"
            @click="datePanelShow = true"
          />
        </van-cell-group>

        <van-calendar
          v-model="datePanelShow"
          @confirm="onConfirmDate"
          :row-height="48"
          position="right"
        />

        <br />

        <div class="btnGroup">
          <van-button type="info" @click="handleRecommendForm">{{btn1Text}}</van-button>
          <!-- <van-button color="#00CCFF" to="/home" v-if="!isResumes && !isRecruitment">{{btn2Text}}</van-button> -->
        </div>
      </ValidationObserver>
    </div>
  </div>
</template>

<script>
import recommendApi from "@/api/recommend";
import memberApi from "@/api/member";
import { ValidationProvider, ValidationObserver } from "vee-validate";

export default {
  props: {
    // 接收父组件传递过来 的数据,通过isDialog来判断 是否为弹框
    // 如果为 true, 则是弹框
    isSubComponent: Boolean,
    propEmpId: String,
    isRecruitment: Boolean,
    propBhMobile: String,
    isResumes: Boolean
  },

  data() {
    return {
      show: false,
      recommendImg: require("@/assets/Images/recommendImg.jpg"), // 我要推荐图片的地址
      recommendName: "",
      recommendForm: {
        // 要传给后台的表单数据
        pid: "", // 赏金猎人ID
        id: "", // 面试人员ID
        bhMobile: "",
        telephone: "",
        name: "",
        empid: "",
        interviewdate: "",
        statusId: "2" // 被推荐人自主推荐时站别为1，猎人推荐时站别为2
      },
      datePanelShow: false,
      btn1Text: "提交",
      btn2Text: "返回首页"
    };
  },

  components: {
    ValidationProvider,
    ValidationObserver
  },

  created() {
    // 对赏金猎人的ID进行获取
    this.SetrecommendForm();

    if (this.isSubComponent) {
      // 作为简历查询子组件时查询面试人员的信息
      this.SetResumes();
    } else {
      // 我要推荐页面，从后台查询得到推荐人姓名
      this.GetRecommendName();
    }
  },

  mounted() {
    if (this.isSubComponent) {
      // 如果是作为没有图片的组件，直接显示内容
      this.show = true;
    } else {
      let img = document.getElementsByClassName("van-image")[0].childNodes[0]; //图片
      img.onload = () => {
        this.show = true;
      };
    }
  },

  methods: {
    // 根据赏金猎人的ID从后台查询得到其姓名
    GetRecommendName() {
      memberApi.getMemberPersonalInfo(this.recommendForm.pid).then(response => {
        const resp = response.data;
        if (resp.flag) {
          const data = resp.data;
          this.recommendName = data.name;
        } else {
          this.$toast.fail(resp.message);
        }
      });
    },

    // 判断是否是收集简历查询页面的子组件，父组件会传propEmpId值（面试人员的id）
    SetResumes() {
      if (this.propEmpId) {
        // 根据name去后台查询该面试人员已存在的信息
        recommendApi.getRecommendedInfos(this.propEmpId).then(response => {
          const resp = response.data;
          if (resp.flag) {
            const data = resp.data;
            this.recommendForm.telephone = data.telephone;
            this.recommendForm.name = data.name;
            this.recommendForm.empid = data.empid;
            this.recommendForm.interviewdate = data.interviewdate;
            this.recommendForm.id = this.propEmpId; // 被推荐人id
          }
        });
      }
    },

    // 对赏金猎人的ID进行获取
    SetrecommendForm() {
      if (this.isRecruitment) {
        // 自主推荐页面进来
        this.btn1Text = "马上申请";
        // this.btn2Text = "我再想想"
        this.recommendForm.statusId = "1"; // 自主填写站别修改为1
        this.recommendForm.pid = this.$route.query.id;
        //delete this.recommendForm.empid
      } else {
        // 我要推荐和建立查询页面进来
        this.recommendForm.pid = this.$store.state.hunter.registeredId;
        //delete this.recommendForm.bhMobile
      }
    },

    formatDate(date) {
      return `${date.getFullYear()}/${date.getMonth() + 1}/${date.getDate()}`;
    },
    // 日期控件
    onConfirmDate(date) {
      this.datePanelShow = false;
      this.recommendForm.interviewdate = this.formatDate(date);
    },

    // 验证成功，提交表单
    submitRecommendForm() {
      recommendApi.addRecommended(this.recommendForm).then(response => {
        const resp = response.data;
        const msg = resp.message;
        if (resp.flag) {
          if (!this.isRecruitment) {
            // 弹出推荐须知（不是作为招募推广的组件）
            this.showDialog1();
          } else {
            // 弹出申请成功（作为招募推广的组件）
            this.showDialog2();
          }
        } else {
          this.$toast.fail(msg);
        }
      });
    },

    // 处理被推荐人表单
    handleRecommendForm() {
      let that = this;
      this.$refs.form.validate().then(res => {
        if (res) {
          // 验证成功，还需要自己判断面日日期不为空
          if (!that.recommendForm.interviewdate) {
            that.$toast("必填项不能为空");
            return;
          }

          that.submitRecommendForm(); // 提交表单
        } else {
          that.$toast("请填写正确信息");
        }
      });
    },

    // 推荐须知弹出框（不是作为招募推广的组件）
    showDialog1() {
      recommendApi.getRecommendNotice().then(response => {
        const resp = response.data;
        const msg = resp.message;

        if (resp.flag && resp.data.length >= 3) {
          const notices = []; // 存储推荐须知中需要用户维护的几个时间
          for (const item of resp.data) {
            notices.push(`<span
            style="color:blue;font-weight:bold;">${item.code}</span>`); // 设置字体显示的样式
          }

          const content = `面试时间：周一~周五（上午8:00，下午12:30）
            面试地点：浙江省宁波市富春招募中心
            所需资料：身份证复印件&一寸照片各5张，身份证原件。
            请告知以上信息至被推荐人，已做到现场面试准备。

            推荐信息有效期为${notices[0]}，若人员在投递推荐信息后${
            notices[1]
          }内未到现场进行面试，则推荐信息失效，推荐信息需重新填写。
            信息填写的面试日期${
              notices[2]
            }内没有入职，视为赏金猎人推荐失效，若此被推荐人后续有入职，则不发放赏金猎人奖金。

            最终解释权归宁波群志光电有限公司所有`.trimMultiSpace();

          this.$dialog
            .alert({
              title: "推荐须知",
              messageAlign: "left",
              message: content
            })
            .then(() => {
              this.$toast.success("提交成功");

              if (!this.isSubComponent) {
                // 如果不是作为收集简历查询组件的子组件，点击确认回到首页
                this.$router.push("/home");
              } else {
                // 如果是，调用收集简历查询组件的方法，关闭弹出框
                this.$emit("close_dialog", false);
              }
            });
        } else {
          this.$toast.fail(msg);
        }
      });
    },

    // 弹出申请成功（作为招募推广的组件）
    showDialog2() {
      const content = `信息已提交至群志光电有限公司，将于7天内与您联系。
      详情请咨询：188-8888-8888`; //.trimMultiSpace();

      this.$dialog
        .alert({
          title: "申请成功",
          messageAlign: "left",
          message: content
        })
        .then(() => {
          this.$toast.success("提交成功");
          //this.$router.push("/home");
        });
    }
  },

  watch: {
    // 监控父组件传过来的propEmpId
    propEmpId() {
      //this.isComponent()
      this.SetResumes();
    },

    // 监控父组件传过来的propBhMobile
    propBhMobile() {
      this.recommendForm.bhMobile = this.propBhMobile;
    }
  }
};
</script>

<style scoped>
.commonFont {
  margin: 3vh 10vw;
  padding-bottom: 1.5vh;
  border-bottom: 0.2vh solid #dcdcdc;
  font-size: 0.9rem;
}

.van-field:not(.noBorder) {
  border-bottom: 0.2vh solid #f5f5f5;
}

.submitForm {
  padding: 0 8vw;
}

.btnGroup .van-button {
  display: block;
  width: 75%;
  margin: 2vh auto;
}
</style>