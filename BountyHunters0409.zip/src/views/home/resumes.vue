<template>
  <div v-show="show">
    <div class="imgDiv" align="center">
      <van-image fit="fill" :src="resumesImg" />
    </div>

    <div class="commonFont">
      <span>收集到简历信息共<span style="color:blue">{{total}}</span>份</span>
    </div>

    <!-- 简历列表部分 -->
    <div class="listDiv loadingArea" v-if="hasResumes">
      <div class="tableTitle">
        <van-row>
          <van-col span="3" align="center">序号</van-col>
          <van-col span="5" align="center">姓名</van-col>
          <van-col span="8" align="center">可面试时间</van-col>
          <van-col span="8" align="center">联系方式</van-col>
        </van-row>
      </div>
      <div class="tableContent">
        <van-list>
          <van-row v-for="item in resumesList" :key="item.id" @click="showDialog(item.id)">
            <van-col span="3" align="center">{{item.sort + 1}}</van-col>
            <van-col span="5" align="center">{{item.name}}</van-col>
            <van-col span="8" align="center">{{item.interviewDate}}</van-col>
            <van-col span="8" align="center">{{item.telephone}}</van-col>
          </van-row>
        </van-list>
      </div>
    </div>

    <van-dialog v-model="dialogShow" title=" " confirm-button-text="取消" >
      <recommend :isSubComponent="true" :isResumes="true" :propEmpId="empId" @close_dialog="closeDialog"></recommend>
      <!-- <br /><br /><br /><br /><br /> -->
    </van-dialog>
  </div>
</template>

<script>
import resumesApi from "@/api/resumes";
import Recommend from "@/views/home/recommend.vue";

export default {
  data() {
    return {
      show: false,
      resumesImg: require("@/assets/Images/resumesImg.jpg"), // 收集简历查询的地址
      resumesList: [],
      total: 0,
      hasResumes: false, 
      dialogShow: false, // 是否显示被推荐人信息对话框
      empId: ""
    };
  },

  components: {
    Recommend
  },

  created() {
    this.fetchResumes();
  },

  mounted() {
    let img = document.getElementsByClassName("van-image")[0].childNodes[0];//图片
    img.onload = () => {
      this.show = true
    }
  },

  methods: {
    // 查询该赏金猎人的收集简历列表
    fetchResumes() {
      const registeredId = this.$store.state.hunter.registeredId // 得到赏金猎人的id
      resumesApi.getResumes(registeredId).then(response => {
        const resp = response.data;
        if (resp.flag) {
          const data = resp.data;
          this.resumesList = data.rows;
          this.total = data.total;
          if(data.total > 0){
            this.hasResumes = true; // 显示简历列表
          }
        }else{
          this.hasResumes = false;
        }
      });
    },

    showDialog(value){
      this.empId = value;
      this.dialogShow = true;
    },

    // beforeClose(action, done) {
    //   /* 先在<van-dialog>加上属性:beforeClose="beforeClose"
    //    beforeClose：相当于一个钩子函数，会在关闭之前执行一些操作，会有两个参数，action, done。
    //     action是点击的目标的名称，如果点击了"确认"按钮，则action为confirm；如果点击了"取消"按钮，则action为cancel。
    //     done是执行关闭的操作。 */
    //   // console.log(action);
    //   done();
    // },

    // 子组件我要推荐调用的方法
    closeDialog(flag){
      // 1. 关闭弹出框
      this.dialogShow = flag;
      // 2. 重新查询列表（简单版），也可以实现前台更新该条信息，不用全部刷新（跟user确认）
      this.fetchResumes();
    }
  }
};
</script>

<style scoped>
.commonFont{
  padding: 1vh 0.8vw;
}

.listDiv {
  padding: 0 0.8vw;
  font-family:Arial,Helvetica,sans-serif;
  color: #606266;
}
.listDiv .tableTitle {
  font-size: 0.9rem;
}
.listDiv .tableContent {
  font-size: 0.8rem;
}
.van-row {
  border-bottom: 1px solid #DCDCDC;
  line-height: 7vh;
}

.van-dialog {
  width: 90%;
  /* height: 60%; */
}
</style>