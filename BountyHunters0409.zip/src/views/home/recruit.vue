<template>
  <div class>
    <div align="center" v-show="show">
        <div class="bgDiv" id="bgDiv" :style="{backgroundImage:`url(${backgroundImg})`,backgroundSize:'100% 100%'}">
            <van-image class="content1" fit="fill" :src="contentImg1"/>
            <van-image class="content2" fit="fill" :src="contentImg2" radius="10" @click="goToAds()"/>         
        </div>  
    </div>
  </div>
</template>

<script>
import { ImagePreview } from 'vant';

export default {
  components: {},

  data() {
    return {
        backgroundImg: require("../../assets/Images/reruitBgImg.jpg"), // 底图的地址
        contentImg1: require("../../assets/Images/reruitContentImg1.png"), // 内容图1
        contentImg2: require("../../assets/Images/reruitContentImg2.png"), // 内容图2
        show: false,    
    };
  },

  mounted(){
    let img = new Image()
    img.src = this.backgroundImg
    img.onload = () => {
      this.show = true
    }
  },

  methods: {
    // 第三步：生成广告+个人专属二维码
    goToAds(){
      this.$router.push({
        path: "/home/recruit/recruitAd"
      })
    }
  },
};
</script>

<style scoped>
.bgDiv{
    width:100%;
}

.van-image{
    width: 90%;
}
.content1{
    margin-top: 44vh;
    margin-bottom: 1vh;
}
.content2{
    margin-bottom: 2vh;
}
.van-button{
  width: 60%;
}


.bgDiv:after {
  content: "";
  height: 20px;
  display: block;
}
</style>