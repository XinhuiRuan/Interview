<template>
  <div>
    <!-- <h1>欢迎访问赏金猎人</h1> -->
    <!-- 轮播图片 -->
    <div class="imgDiv">
      <van-swipe :autoplay="3000" >
        <van-swipe-item v-for="(image, index) in swipeImgs" :key="index">
          <a :href=image.to>
            <van-image fit="fill" :src=image.url />
          </a>
        </van-swipe-item>
      </van-swipe>
    </div>

    <!-- CODE: {{code}} -->

    <!-- 四个按钮布局 -->
    <table width="100%">
      <tr style="height: 12vh;">
        <td class="td1">
          <van-button type="info" to="/home/join">我要加入</van-button>
        </td>
        <td class="td2">
          <van-button color="#FF9900" to="/home/recommend">我要推荐</van-button>
        </td>
      </tr>
       <tr style="height: 9.5vh;">
        <td class="td3">
          <van-button color="#00CCFF" to="/home/recruit">招募推广</van-button>
        </td>
        <td class="td4">
          <van-button color="#00CCFF" to="/home/resumes">简历查询</van-button>
        </td>
      </tr> 
    </table>
    
    <div class="imgDiv" align="center">
      <a :href=promotionImg.to>
        <van-image fit="fill" :src=promotionImg.url />
      </a>
    </div>

    <div align="center">
      <a :href=promotionImg.to>
        <h3>招聘信息一键发布</h3>
      </a>
    </div>
    
  </div>
</template>

<script>
import util from '@/utils/weixin.js'
import homeApi from "@/api/home";

export default {
  data() {
    return {
      //code: '',
      swipeImgs: [
        {
          url: require('@/assets/TmpImages/swipeImg1.jpg'),
          to: "https://www.baidu.com"
        },
        {
          url: require('@/assets/TmpImages/swipeImg2.jpg'),
          to: "https://www.baidu.com"
        }
      ],
      promotionImg: {
        url: require('@/assets/TmpImages/swipeImg2.jpg'),
        to: "https://www.baidu.com"
      }
      // swipeImgs: [],
      // promotionImg: {}
    }
  },

  components: {},

  // 钩子函数获取图片数据
  created() {
    // this.code = util.getUrlParam("code")
    //this.fetchImgs();
  },
  
  methods: {
    // 获取轮播和宣传栏的图片信息
    fetchImgs(){
      homeApi.getHomeImgs("home").then(response => {
        const resp = response.data
        if(resp.flag){ // 查询成功
          const imgs = resp.data       
          for(const item of imgs){
            // 修改后台传回的对象属性名
            let imgObj = {
                index: item.ad_position,
                url: item.pic_catalog,
                to: item.jump_website
            };

            if(item.ad_type == "promotion"){
              this.promotionImg = imgObj
            }else if(item.ad_type == "swipe"){
              this.swipeImgs[imgObj.index] = imgObj
            }
          }
        }
      })
    }
  },

}
</script>

<style scoped>
.td1{
  width: 54vw;
  text-align: center;
  vertical-align: middle;
}
.td2{
  width: 46vw;
  text-align: left;
  vertical-align: middle;
}
.td3{
  width: 54vw;
  text-align: center;
  vertical-align: top;
}
.td4{
  width: 46vw;
  text-align: left;
  vertical-align: top;
}
.van-button{
  height: 7vh;
  width:38vw;
}

h3{
  margin: 2vh 0;
  color: black;
}

h3:after
{
  content : '';
  height : 50px;
  display :block;
}
</style>