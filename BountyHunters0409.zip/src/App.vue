<template>
  <div id="app">
    <!-- 路由组件渲染出口 -->
    <router-view></router-view>
  </div>
</template>

<style>
  /* 上面不要加 scoped */
  body {
    /* font-family: "微软雅黑"; */
    font-family: Microsoft YaHei;
    /* 满屏显示, 不显示默认边距 margin:8px, */
    margin: 0px auto;
  }

  /* 全局设置图片高度占整个屏幕的25% */
  .imgDiv{
    height: 25vh;
    padding: 0 0.8vw;
  }
  .imgDiv .van-swipe, .imgDiv .van-image{
    width: 100%;
    height: 100%;
  } 

  .commonFont span{
    font-family:Arial,Helvetica,sans-serif;
    color: #606266;
    font-weight: bold;
  }
</style>