<template>
  <div>
    
     <el-breadcrumb separator-class="el-icon-arrow-right">
       <!-- 获取导航名称使用 $route.meta.title , 路由地址使用 $route.path -->
      <!-- <el-breadcrumb-item :class="elClass" :to="{path: $route.path}"> -->
        <el-breadcrumb-item :class="elClass">
          <div @click="back">
            <i v-if="show" class="el-icon-back" >&nbsp;</i>
            <span v-text='$route.meta.title'></span>
          </div>
        </el-breadcrumb-item>
    </el-breadcrumb>
  </div>
</template>

<script>
export default {
  data () {
    return {
      elClass: "",
      backPath: "",
      show: true,
    }
  },

  components: {},

  created(){
    this.SetIcon()  
  },

  methods: {
    // 如果是首页，则没有返回功能；如果不是，则可以返回上一页
    SetIcon(){
      this.backPath = ""
      const curPath = this.$route.path
      let arr = curPath.split('/').filter(item => item != '');

      if(arr.length < 2){
        this.elClass = "line";
        this.show = false;
      }else{
        for(let i=0; i<arr.length-1; i++){
          this.backPath += "/" + arr[i];
        }
      }
    },

    // 返回上一页
    back(){
      this.$router.push(this.backPath);
    }
  },

  watch: {
    $route(){ //跳转到该页面后需要进行的操作
      this.SetIcon()  
    }
  }
}
</script>

<style scoped>
.el-breadcrumb {
  height: 10px;
  padding: 20px;
  border-radius: 4px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  background: #F5F5F5;
  font-size: 0.7rem;
}

.line {
  border-left: 3px solid #31c17b;
  padding-left: 10px;
}

/* .el-breadcrumb {
  height: 10px;
  padding: 20px 0.8vw;
  border-radius: 4px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
} */


</style>